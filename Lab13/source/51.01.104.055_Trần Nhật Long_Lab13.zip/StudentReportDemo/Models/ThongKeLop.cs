namespace StudentReportDemo.Models;

public class ThongKeLop
{
    public string MaLop { get; set; } = string.Empty;
    public string TenLop { get; set; } = string.Empty;
    public int SoSinhVien { get; set; }
    public int SoDat { get; set; }
    public int SoKhongDat { get; set; }
    public double DiemTrungBinh { get; set; }
}
