namespace StudentReportDemo.Models;

public class LopItem
{
    public LopItem(string? maLop, string tenLop)
    {
        MaLop = maLop;
        TenLop = tenLop;
    }

    public string? MaLop { get; }
    public string TenLop { get; }

    public string HienThi
    {
        get { return MaLop == null ? TenLop : MaLop + " - " + TenLop; }
    }
}
