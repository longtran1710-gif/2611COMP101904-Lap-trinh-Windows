namespace StudentReportDemo.Models;

public class SinhVien
{
    public const string Dat = "Đạt";
    public const string KhongDat = "Không đạt";

    public string MaSV { get; set; } = string.Empty;
    public string HoTen { get; set; } = string.Empty;
    public string MaLop { get; set; } = string.Empty;
    public string TenLop { get; set; } = string.Empty;
    public double Diem { get; set; }

    public string KetQua
    {
        get { return Diem >= 5 ? Dat : KhongDat; }
    }
}
