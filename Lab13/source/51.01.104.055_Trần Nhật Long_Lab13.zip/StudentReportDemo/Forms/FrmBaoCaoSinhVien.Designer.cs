using System;
using System.Drawing;
using System.Windows.Forms;

namespace StudentReportDemo.Forms;

partial class FrmBaoCaoSinhVien
{
    private System.ComponentModel.IContainer components = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        pnlTop = new Panel();
        lblLop = new Label();
        lblKetQua = new Label();
        lblTuKhoa = new Label();
        cboLop = new ComboBox();
        cboKetQua = new ComboBox();
        txtTuKhoa = new TextBox();
        btnXemBaoCao = new Button();
        btnThongKe = new Button();
        btnXuatFile = new Button();
        dgvBaoCao = new DataGridView();
        lblTongHop = new Label();
        lblStatus = new Label();
        ((System.ComponentModel.ISupportInitialize)dgvBaoCao).BeginInit();
        SuspendLayout();

        pnlTop.Name = "pnlTop";
        pnlTop.Dock = DockStyle.Top;
        pnlTop.Height = 105;
        pnlTop.Controls.AddRange(new Control[]
        {
            lblLop, cboLop, lblKetQua, cboKetQua, lblTuKhoa, txtTuKhoa, btnXemBaoCao, btnThongKe, btnXuatFile
        });

        lblLop.Name = "lblLop"; lblLop.Text = "Lớp:"; lblLop.AutoSize = true; lblLop.Location = new Point(15, 22);
        cboLop.Name = "cboLop"; cboLop.DropDownStyle = ComboBoxStyle.DropDownList;
        cboLop.Location = new Point(85, 19); cboLop.Size = new Size(260, 23);

        lblKetQua.Name = "lblKetQua"; lblKetQua.Text = "Kết quả:"; lblKetQua.AutoSize = true; lblKetQua.Location = new Point(375, 22);
        cboKetQua.Name = "cboKetQua"; cboKetQua.DropDownStyle = ComboBoxStyle.DropDownList;
        cboKetQua.Location = new Point(440, 19); cboKetQua.Size = new Size(150, 23);

        lblTuKhoa.Name = "lblTuKhoa"; lblTuKhoa.Text = "Từ khóa:"; lblTuKhoa.AutoSize = true; lblTuKhoa.Location = new Point(15, 66);
        txtTuKhoa.Name = "txtTuKhoa"; txtTuKhoa.Location = new Point(85, 63); txtTuKhoa.Size = new Size(260, 23);
        txtTuKhoa.KeyDown += txtTuKhoa_KeyDown;

        btnXemBaoCao.Name = "btnXemBaoCao"; btnXemBaoCao.Text = "Xem báo cáo";
        btnXemBaoCao.Location = new Point(375, 58); btnXemBaoCao.Size = new Size(115, 34);
        btnXemBaoCao.Click += btnXemBaoCao_Click;

        btnThongKe.Name = "btnThongKe"; btnThongKe.Text = "Thống kê";
        btnThongKe.Location = new Point(500, 58); btnThongKe.Size = new Size(100, 34);
        btnThongKe.Click += btnThongKe_Click;

        btnXuatFile.Name = "btnXuatFile"; btnXuatFile.Text = "Xuất file";
        btnXuatFile.Location = new Point(610, 58); btnXuatFile.Size = new Size(100, 34);
        btnXuatFile.Click += btnXuatFile_Click;

        dgvBaoCao.Name = "dgvBaoCao";
        dgvBaoCao.Dock = DockStyle.Fill;
        dgvBaoCao.BackgroundColor = SystemColors.Window;
        dgvBaoCao.ReadOnly = true;
        dgvBaoCao.AllowUserToAddRows = false;
        dgvBaoCao.AllowUserToDeleteRows = false;
        dgvBaoCao.AutoGenerateColumns = false;
        dgvBaoCao.RowHeadersVisible = false;
        dgvBaoCao.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvBaoCao.MultiSelect = false;
        dgvBaoCao.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        lblTongHop.Name = "lblTongHop";
        lblTongHop.Dock = DockStyle.Bottom;
        lblTongHop.Height = 32;
        lblTongHop.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
        lblTongHop.TextAlign = ContentAlignment.MiddleLeft;
        lblTongHop.Padding = new Padding(10, 0, 0, 0);

        lblStatus.Name = "lblStatus";
        lblStatus.Dock = DockStyle.Bottom;
        lblStatus.Height = 26;
        lblStatus.TextAlign = ContentAlignment.MiddleLeft;
        lblStatus.BorderStyle = BorderStyle.Fixed3D;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(760, 560);
        MinimumSize = new Size(740, 420);
        StartPosition = FormStartPosition.CenterScreen;
        Name = "FrmBaoCaoSinhVien";
        Text = "Báo cáo sinh viên theo lớp";
        Controls.Add(dgvBaoCao);
        Controls.Add(pnlTop);
        Controls.Add(lblTongHop);
        Controls.Add(lblStatus);
        Load += FrmBaoCaoSinhVien_Load;

        ((System.ComponentModel.ISupportInitialize)dgvBaoCao).EndInit();
        ResumeLayout(false);
    }

    private Panel pnlTop = null!;
    private Label lblLop = null!;
    private Label lblKetQua = null!;
    private Label lblTuKhoa = null!;
    private ComboBox cboLop = null!;
    private ComboBox cboKetQua = null!;
    private TextBox txtTuKhoa = null!;
    private Button btnXemBaoCao = null!;
    private Button btnThongKe = null!;
    private Button btnXuatFile = null!;
    private DataGridView dgvBaoCao = null!;
    private Label lblTongHop = null!;
    private Label lblStatus = null!;
}
