using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using StudentReportDemo.Models;

namespace StudentReportDemo.Forms;

public partial class FrmBaoCaoSinhVien : Form
{
    private enum CheDoHienThi
    {
        BaoCao,
        ThongKe
    }

    private const string TatCaKetQua = "Tất cả";
    private static readonly CultureInfo Invariant = CultureInfo.InvariantCulture;

    private readonly List<SinhVien> danhSachSinhVien;
    private List<SinhVien> baoCaoHienTai = new List<SinhVien>();
    private List<ThongKeLop> thongKeHienTai = new List<ThongKeLop>();
    private CheDoHienThi cheDo = CheDoHienThi.BaoCao;

    public FrmBaoCaoSinhVien()
    {
        InitializeComponent();
        danhSachSinhVien = TaoDuLieuMau();
    }

    private void FrmBaoCaoSinhVien_Load(object? sender, EventArgs e)
    {
        LoadComboBox();
        XemBaoCao(false);
    }

    private static List<SinhVien> TaoDuLieuMau()
    {
        const string cntt01 = "Công nghệ thông tin 01";
        const string cntt02 = "Công nghệ thông tin 02";
        const string sptin01 = "Sư phạm Tin học 01";
        const string sptoan01 = "Sư phạm Toán 01";

        return new List<SinhVien>
        {
            new SinhVien { MaSV = "SV001", HoTen = "Nguyễn Văn An", MaLop = "CNTT01", TenLop = cntt01, Diem = 8.5 },
            new SinhVien { MaSV = "SV002", HoTen = "Trần Thị Bình", MaLop = "CNTT01", TenLop = cntt01, Diem = 7.0 },
            new SinhVien { MaSV = "SV003", HoTen = "Lê Minh Chi", MaLop = "CNTT01", TenLop = cntt01, Diem = 4.5 },
            new SinhVien { MaSV = "SV004", HoTen = "Phạm Quốc Dũng", MaLop = "CNTT01", TenLop = cntt01, Diem = 9.0 },
            new SinhVien { MaSV = "SV005", HoTen = "Hoàng Gia Hân", MaLop = "CNTT01", TenLop = cntt01, Diem = 3.5 },
            new SinhVien { MaSV = "SV006", HoTen = "Võ Thành Khang", MaLop = "CNTT02", TenLop = cntt02, Diem = 6.5 },
            new SinhVien { MaSV = "SV007", HoTen = "Đặng Thu Lan", MaLop = "CNTT02", TenLop = cntt02, Diem = 5.0 },
            new SinhVien { MaSV = "SV008", HoTen = "Bùi Anh Minh", MaLop = "CNTT02", TenLop = cntt02, Diem = 4.0 },
            new SinhVien { MaSV = "SV009", HoTen = "Ngô Thị Ngọc", MaLop = "CNTT02", TenLop = cntt02, Diem = 8.0 },
            new SinhVien { MaSV = "SV010", HoTen = "Lý Văn Phúc", MaLop = "CNTT02", TenLop = cntt02, Diem = 7.5 },
            new SinhVien { MaSV = "SV011", HoTen = "Trương Mỹ Quyên", MaLop = "SPTIN01", TenLop = sptin01, Diem = 9.5 },
            new SinhVien { MaSV = "SV012", HoTen = "Đỗ Hoàng Sơn", MaLop = "SPTIN01", TenLop = sptin01, Diem = 5.5 },
            new SinhVien { MaSV = "SV013", HoTen = "Phan Thị Thảo", MaLop = "SPTIN01", TenLop = sptin01, Diem = 2.5 },
            new SinhVien { MaSV = "SV014", HoTen = "Huỳnh Gia Uy", MaLop = "SPTIN01", TenLop = sptin01, Diem = 6.0 },
            new SinhVien { MaSV = "SV015", HoTen = "Mai Anh Vy", MaLop = "SPTOAN01", TenLop = sptoan01, Diem = 7.0 },
            new SinhVien { MaSV = "SV016", HoTen = "Cao Văn Xuân", MaLop = "SPTOAN01", TenLop = sptoan01, Diem = 4.8 }
        };
    }

    private void LoadComboBox()
    {
        List<LopItem> lopItems = danhSachSinhVien
            .Select(sv => new { sv.MaLop, sv.TenLop })
            .Distinct()
            .OrderBy(lop => lop.MaLop)
            .Select(lop => new LopItem(lop.MaLop, lop.TenLop))
            .ToList();
        lopItems.Insert(0, new LopItem(null, "Tất cả lớp"));

        cboLop.DisplayMember = nameof(LopItem.HienThi);
        cboLop.DataSource = lopItems;

        cboKetQua.Items.Clear();
        cboKetQua.Items.AddRange(new object[] { TatCaKetQua, SinhVien.Dat, SinhVien.KhongDat });
        cboKetQua.SelectedIndex = 0;
    }

    private List<SinhVien> LocDuLieu()
    {
        string? maLop = (cboLop.SelectedItem as LopItem)?.MaLop;
        string ketQua = cboKetQua.SelectedItem?.ToString() ?? TatCaKetQua;
        string tuKhoa = txtTuKhoa.Text.Trim();

        IEnumerable<SinhVien> query = danhSachSinhVien;

        if (maLop != null)
        {
            query = query.Where(sv => sv.MaLop == maLop);
        }

        if (ketQua != TatCaKetQua)
        {
            query = query.Where(sv => sv.KetQua == ketQua);
        }

        if (tuKhoa.Length > 0)
        {
            query = query.Where(sv =>
                sv.MaSV.Contains(tuKhoa, StringComparison.OrdinalIgnoreCase) ||
                sv.HoTen.Contains(tuKhoa, StringComparison.OrdinalIgnoreCase));
        }

        return query
            .OrderByDescending(sv => sv.Diem)
            .ThenBy(sv => sv.HoTen)
            .ToList();
    }

    private void XemBaoCao(bool hienThongBao)
    {
        baoCaoHienTai = LocDuLieu();
        cheDo = CheDoHienThi.BaoCao;

        CauHinhCotBaoCao();
        dgvBaoCao.DataSource = baoCaoHienTai;
        CapNhatTongHop(baoCaoHienTai);

        if (baoCaoHienTai.Count == 0)
        {
            lblStatus.Text = "Không có sinh viên nào phù hợp với điều kiện lọc.";
            if (hienThongBao)
            {
                MessageBox.Show("Không có sinh viên nào phù hợp với điều kiện lọc.\nHãy thử đổi lớp, kết quả hoặc từ khóa.",
                    "Không có dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        else
        {
            lblStatus.Text = $"Báo cáo: {baoCaoHienTai.Count} sinh viên, sắp xếp giảm dần theo điểm.";
        }
    }

    private void CapNhatThongKe()
    {
        thongKeHienTai = TinhThongKeTheoLop(danhSachSinhVien);
        cheDo = CheDoHienThi.ThongKe;

        CauHinhCotThongKe();
        dgvBaoCao.DataSource = thongKeHienTai;
        CapNhatTongHop(danhSachSinhVien);
        lblStatus.Text = $"Thống kê: {thongKeHienTai.Count} lớp, {danhSachSinhVien.Count} sinh viên.";
    }

    private static List<ThongKeLop> TinhThongKeTheoLop(IEnumerable<SinhVien> nguon)
    {
        return nguon
            .GroupBy(sv => new { sv.MaLop, sv.TenLop })
            .Select(nhom => new ThongKeLop
            {
                MaLop = nhom.Key.MaLop,
                TenLop = nhom.Key.TenLop,
                SoSinhVien = nhom.Count(),
                SoDat = nhom.Count(sv => sv.KetQua == SinhVien.Dat),
                SoKhongDat = nhom.Count(sv => sv.KetQua == SinhVien.KhongDat),
                DiemTrungBinh = Math.Round(nhom.Average(sv => sv.Diem), 2)
            })
            .OrderBy(thongKe => thongKe.MaLop)
            .ToList();
    }

    private void CapNhatTongHop(IReadOnlyCollection<SinhVien> data)
    {
        int tong = data.Count;
        int soDat = data.Count(sv => sv.KetQua == SinhVien.Dat);
        int soKhongDat = data.Count(sv => sv.KetQua == SinhVien.KhongDat);
        double diemTrungBinh = tong == 0 ? 0 : data.Average(sv => sv.Diem);

        lblTongHop.Text =
            $"Tổng: {tong}   |   Đạt: {soDat}   |   Không đạt: {soKhongDat}   |   Điểm trung bình: {diemTrungBinh.ToString("0.00", Invariant)}";
    }

    private void CauHinhCotBaoCao()
    {
        dgvBaoCao.DataSource = null;
        dgvBaoCao.Columns.Clear();

        var diemStyle = new DataGridViewCellStyle
        {
            Format = "0.0#",
            FormatProvider = Invariant,
            Alignment = DataGridViewContentAlignment.MiddleRight
        };

        dgvBaoCao.Columns.Add(TaoCot(nameof(SinhVien.MaSV), "Mã SV", 60));
        dgvBaoCao.Columns.Add(TaoCot(nameof(SinhVien.HoTen), "Họ tên", 140));
        dgvBaoCao.Columns.Add(TaoCot(nameof(SinhVien.TenLop), "Lớp", 130));
        dgvBaoCao.Columns.Add(TaoCot(nameof(SinhVien.Diem), "Điểm", 50, diemStyle));
        dgvBaoCao.Columns.Add(TaoCot(nameof(SinhVien.KetQua), "Kết quả", 70));
    }

    private void CauHinhCotThongKe()
    {
        dgvBaoCao.DataSource = null;
        dgvBaoCao.Columns.Clear();

        var soStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleRight };
        var diemStyle = new DataGridViewCellStyle
        {
            Format = "0.00",
            FormatProvider = Invariant,
            Alignment = DataGridViewContentAlignment.MiddleRight
        };

        dgvBaoCao.Columns.Add(TaoCot(nameof(ThongKeLop.MaLop), "Mã lớp", 70));
        dgvBaoCao.Columns.Add(TaoCot(nameof(ThongKeLop.TenLop), "Tên lớp", 140));
        dgvBaoCao.Columns.Add(TaoCot(nameof(ThongKeLop.SoSinhVien), "Số sinh viên", 70, soStyle));
        dgvBaoCao.Columns.Add(TaoCot(nameof(ThongKeLop.SoDat), "Số đạt", 55, soStyle));
        dgvBaoCao.Columns.Add(TaoCot(nameof(ThongKeLop.SoKhongDat), "Số không đạt", 70, soStyle));
        dgvBaoCao.Columns.Add(TaoCot(nameof(ThongKeLop.DiemTrungBinh), "Điểm trung bình", 80, diemStyle));
    }

    private static DataGridViewTextBoxColumn TaoCot(string property, string tieuDe, float doRong,
        DataGridViewCellStyle? style = null)
    {
        var cot = new DataGridViewTextBoxColumn
        {
            Name = "col" + property,
            DataPropertyName = property,
            HeaderText = tieuDe,
            FillWeight = doRong
        };

        if (style != null)
        {
            cot.DefaultCellStyle = style;
        }

        return cot;
    }

    private (string[] TieuDe, List<string[]> Dong) LayDuLieuXuat()
    {
        if (cheDo == CheDoHienThi.ThongKe)
        {
            string[] tieuDeThongKe = { "MaLop", "TenLop", "SoSinhVien", "SoDat", "SoKhongDat", "DiemTrungBinh" };
            List<string[]> dongThongKe = thongKeHienTai
                .Select(tk => new[]
                {
                    tk.MaLop, tk.TenLop, tk.SoSinhVien.ToString(Invariant), tk.SoDat.ToString(Invariant),
                    tk.SoKhongDat.ToString(Invariant), tk.DiemTrungBinh.ToString("0.00", Invariant)
                })
                .ToList();
            return (tieuDeThongKe, dongThongKe);
        }

        string[] tieuDeBaoCao = { "MaSV", "HoTen", "MaLop", "TenLop", "Diem", "KetQua" };
        List<string[]> dongBaoCao = baoCaoHienTai
            .Select(sv => new[]
            {
                sv.MaSV, sv.HoTen, sv.MaLop, sv.TenLop, sv.Diem.ToString("0.0#", Invariant), sv.KetQua
            })
            .ToList();
        return (tieuDeBaoCao, dongBaoCao);
    }

    private static string EscapeCsv(string value)
    {
        bool canDauNhay = value.IndexOfAny(new[] { ',', '"', '\n', '\r' }) >= 0;
        return canDauNhay ? "\"" + value.Replace("\"", "\"\"") + "\"" : value;
    }

    private void XuatFile()
    {
        (string[] tieuDe, List<string[]> dong) = LayDuLieuXuat();

        if (dong.Count == 0)
        {
            MessageBox.Show("Chưa có dữ liệu để xuất. Hãy bấm Xem báo cáo hoặc Thống kê và đảm bảo có kết quả.",
                "Không có dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        string tenMacDinh = (cheDo == CheDoHienThi.ThongKe ? "ThongKeLop_" : "BaoCaoSinhVien_")
                            + DateTime.Now.ToString("yyyyMMdd_HHmm", Invariant);

        using var dialog = new SaveFileDialog();
        dialog.Title = "Xuất báo cáo";
        dialog.Filter = "CSV file (*.csv)|*.csv|Text file (*.txt)|*.txt";
        dialog.FileName = tenMacDinh;
        dialog.AddExtension = true;
        dialog.DefaultExt = "csv";

        if (dialog.ShowDialog() != DialogResult.OK) return;

        bool laTxt = Path.GetExtension(dialog.FileName).Equals(".txt", StringComparison.OrdinalIgnoreCase);
        IEnumerable<string> cacDong = Enumerable.Repeat(tieuDe, 1)
            .Concat(dong)
            .Select(truong => laTxt
                ? string.Join("\t", truong)
                : string.Join(",", truong.Select(EscapeCsv)));

        try
        {
            File.WriteAllLines(dialog.FileName, cacDong, new UTF8Encoding(true));
            lblStatus.Text = $"Đã xuất {dong.Count} dòng ra file {Path.GetFileName(dialog.FileName)}";
            MessageBox.Show($"Đã xuất {dong.Count} dòng ra file:\n{dialog.FileName}", "Xuất file thành công",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is System.Security.SecurityException)
        {
            lblStatus.Text = "Xuất file thất bại";
            MessageBox.Show("Không thể ghi file. Hãy kiểm tra file có đang được mở ở chương trình khác hoặc chọn thư mục khác.\n\nChi tiết: " + ex.Message,
                "Lỗi xuất file", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btnXemBaoCao_Click(object? sender, EventArgs e)
    {
        XemBaoCao(true);
    }

    private void btnThongKe_Click(object? sender, EventArgs e)
    {
        CapNhatThongKe();
    }

    private void btnXuatFile_Click(object? sender, EventArgs e)
    {
        XuatFile();
    }

    private void txtTuKhoa_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Enter)
        {
            e.SuppressKeyPress = true;
            XemBaoCao(true);
        }
    }
}
