using Microsoft.Data.SqlClient;

namespace QLSinhVienLab12.DAL;

public static class Database
{
    public const string ConnectionString =
        "Server=localhost\\SQLEXPRESS;Database=QLSinhVienLab12;Trusted_Connection=True;TrustServerCertificate=True;";

    public static SqlConnection CreateConnection()
    {
        return new SqlConnection(ConnectionString);
    }
}
