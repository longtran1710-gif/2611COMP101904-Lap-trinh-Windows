using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using QLSinhVienLab12.Models;

namespace QLSinhVienLab12.DAL;

public class KetQuaDAL
{
    public DataTable GetLopList()
    {
        return FillTable("sp_Lop_GetAll");
    }

    public DataTable GetMonHocList()
    {
        return FillTable("sp_MonHoc_GetAll");
    }

    public DataTable GetByLopMon(string maLop, string maMon)
    {
        using SqlConnection connection = Database.CreateConnection();
        using var command = new SqlCommand("sp_KetQua_GetByLopMon", connection);
        command.CommandType = CommandType.StoredProcedure;
        command.Parameters.Add("@MaLop", SqlDbType.VarChar, 20).Value = maLop;
        command.Parameters.Add("@MaMon", SqlDbType.VarChar, 20).Value = maMon;

        using var adapter = new SqlDataAdapter(command);
        var table = new DataTable();
        adapter.Fill(table);
        return table;
    }

    public int SaveAll(string maMon, IReadOnlyList<KetQuaItem> items)
    {
        using SqlConnection connection = Database.CreateConnection();
        connection.Open();
        using SqlTransaction transaction = connection.BeginTransaction();

        try
        {
            int saved = 0;
            foreach (KetQuaItem item in items)
            {
                SaveOne(connection, transaction, maMon, item);
                saved++;
            }

            transaction.Commit();
            return saved;
        }
        catch
        {
            TryRollback(transaction);
            throw;
        }
    }

    private static void SaveOne(SqlConnection connection, SqlTransaction transaction, string maMon, KetQuaItem item)
    {
        using var command = new SqlCommand("sp_KetQua_Save", connection, transaction);
        command.CommandType = CommandType.StoredProcedure;
        command.Parameters.Add("@MaSV", SqlDbType.VarChar, 20).Value = item.MaSV;
        command.Parameters.Add("@MaMon", SqlDbType.VarChar, 20).Value = maMon;

        SqlParameter diem = command.Parameters.Add("@Diem", SqlDbType.Decimal);
        diem.Precision = 4;
        diem.Scale = 2;
        diem.Value = item.Diem;

        command.Parameters.Add("@GhiChu", SqlDbType.NVarChar, 200).Value = (object?)item.GhiChu ?? DBNull.Value;
        command.ExecuteNonQuery();
    }

    private static void TryRollback(SqlTransaction transaction)
    {
        try
        {
            transaction.Rollback();
        }
        catch (InvalidOperationException)
        {
        }
    }

    private static DataTable FillTable(string procedureName)
    {
        using SqlConnection connection = Database.CreateConnection();
        using var command = new SqlCommand(procedureName, connection);
        command.CommandType = CommandType.StoredProcedure;

        using var adapter = new SqlDataAdapter(command);
        var table = new DataTable();
        adapter.Fill(table);
        return table;
    }
}
