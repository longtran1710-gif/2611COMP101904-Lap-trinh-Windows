﻿USE master;
GO

IF DB_ID(N'QLSinhVienLab12') IS NOT NULL
BEGIN
    ALTER DATABASE QLSinhVienLab12 SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE QLSinhVienLab12;
END
GO

CREATE DATABASE QLSinhVienLab12;
GO

USE QLSinhVienLab12;
GO

CREATE TABLE LOP
(
    MaLop   VARCHAR(20)   NOT NULL,
    TenLop  NVARCHAR(100) NOT NULL,
    CONSTRAINT PK_LOP PRIMARY KEY (MaLop)
);
GO

CREATE TABLE SINHVIEN
(
    MaSV      VARCHAR(20)   NOT NULL,
    HoTen     NVARCHAR(100) NOT NULL,
    NgaySinh  DATE          NULL,
    MaLop     VARCHAR(20)   NOT NULL,
    CONSTRAINT PK_SINHVIEN PRIMARY KEY (MaSV),
    CONSTRAINT FK_SINHVIEN_LOP FOREIGN KEY (MaLop) REFERENCES LOP (MaLop)
);
GO

CREATE TABLE MONHOC
(
    MaMon     VARCHAR(20)   NOT NULL,
    TenMon    NVARCHAR(100) NOT NULL,
    SoTinChi  INT           NOT NULL,
    CONSTRAINT PK_MONHOC PRIMARY KEY (MaMon),
    CONSTRAINT CK_MONHOC_SoTinChi CHECK (SoTinChi > 0)
);
GO

CREATE TABLE KETQUA
(
    MaSV    VARCHAR(20)  NOT NULL,
    MaMon   VARCHAR(20)  NOT NULL,
    Diem    DECIMAL(4,2) NOT NULL,
    GhiChu  NVARCHAR(200) NULL,
    CONSTRAINT PK_KETQUA PRIMARY KEY (MaSV, MaMon),
    CONSTRAINT CK_KETQUA_Diem CHECK (Diem BETWEEN 0 AND 10),
    CONSTRAINT FK_KETQUA_SINHVIEN FOREIGN KEY (MaSV) REFERENCES SINHVIEN (MaSV),
    CONSTRAINT FK_KETQUA_MONHOC FOREIGN KEY (MaMon) REFERENCES MONHOC (MaMon)
);
GO

INSERT INTO LOP (MaLop, TenLop) VALUES
('CNTT01',  N'Công nghệ thông tin 01'),
('CNTT02',  N'Công nghệ thông tin 02'),
('SPTIN01', N'Sư phạm Tin học 01');
GO

INSERT INTO SINHVIEN (MaSV, HoTen, NgaySinh, MaLop) VALUES
('SV001', N'Nguyễn Văn An',   '2005-02-10', 'CNTT01'),
('SV002', N'Trần Thị Bình',   '2005-08-21', 'CNTT01'),
('SV003', N'Lê Minh Chi',     '2004-12-02', 'CNTT01'),
('SV004', N'Phạm Quốc Dũng',  '2005-04-16', 'CNTT01'),
('SV005', N'Hoàng Gia Hân',   '2005-10-30', 'CNTT02'),
('SV006', N'Võ Thành Khang',  '2004-09-09', 'CNTT02'),
('SV007', N'Đặng Thu Lan',    '2005-06-18', 'CNTT02'),
('SV008', N'Bùi Anh Minh',    '2005-01-25', 'SPTIN01');
GO

INSERT INTO MONHOC (MaMon, TenMon, SoTinChi) VALUES
('MH01', N'Lập trình trên Windows',       3),
('MH02', N'Cơ sở dữ liệu',                3),
('MH03', N'Cấu trúc dữ liệu và giải thuật', 4);
GO

INSERT INTO KETQUA (MaSV, MaMon, Diem, GhiChu) VALUES
('SV001', 'MH01', 8.50, N'Khá'),
('SV002', 'MH01', 7.00, NULL),
('SV005', 'MH02', 9.00, N'Giỏi');
GO

CREATE OR ALTER PROCEDURE sp_Lop_GetAll
AS
BEGIN
    SET NOCOUNT ON;

    SELECT MaLop, TenLop
    FROM LOP
    ORDER BY MaLop;
END
GO

CREATE OR ALTER PROCEDURE sp_MonHoc_GetAll
AS
BEGIN
    SET NOCOUNT ON;

    SELECT MaMon, TenMon, SoTinChi
    FROM MONHOC
    ORDER BY MaMon;
END
GO

CREATE OR ALTER PROCEDURE sp_KetQua_GetByLopMon
    @MaLop VARCHAR(20),
    @MaMon VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT sv.MaSV, sv.HoTen, kq.Diem, kq.GhiChu
    FROM SINHVIEN sv
    LEFT JOIN KETQUA kq ON kq.MaSV = sv.MaSV AND kq.MaMon = @MaMon
    WHERE sv.MaLop = @MaLop
    ORDER BY sv.MaSV;
END
GO

CREATE OR ALTER PROCEDURE sp_KetQua_Save
    @MaSV   VARCHAR(20),
    @MaMon  VARCHAR(20),
    @Diem   DECIMAL(4,2),
    @GhiChu NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @Diem IS NULL OR @Diem < 0 OR @Diem > 10
        THROW 50001, N'Điểm phải nằm trong khoảng 0 đến 10.', 1;

    IF EXISTS (SELECT 1 FROM KETQUA WHERE MaSV = @MaSV AND MaMon = @MaMon)
        UPDATE KETQUA
        SET Diem = @Diem, GhiChu = @GhiChu
        WHERE MaSV = @MaSV AND MaMon = @MaMon;
    ELSE
        INSERT INTO KETQUA (MaSV, MaMon, Diem, GhiChu)
        VALUES (@MaSV, @MaMon, @Diem, @GhiChu);
END
GO

EXEC sp_KetQua_GetByLopMon @MaLop = 'CNTT01', @MaMon = 'MH01';
GO
