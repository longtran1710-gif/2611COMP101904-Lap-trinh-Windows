using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using QLSinhVienLab12.DAL;
using QLSinhVienLab12.Models;

namespace QLSinhVienLab12.Forms;

public partial class FrmNhapDiemTheoLop : Form
{
    private const string DiemColumnName = "colDiem";

    private readonly KetQuaDAL dal = new KetQuaDAL();
    private readonly BindingSource bsKetQua = new BindingSource();
    private DataTable? dtKetQua;
    private string loadedMaLop = string.Empty;
    private string loadedMaMon = string.Empty;

    public FrmNhapDiemTheoLop()
    {
        InitializeComponent();
    }

    private void FrmNhapDiemTheoLop_Load(object? sender, EventArgs e)
    {
        ConfigureGrid();
        dgvKetQua.DataSource = bsKetQua;
        LoadComboBoxes();
    }

    private void ConfigureGrid()
    {
        dgvKetQua.AutoGenerateColumns = false;
        dgvKetQua.AllowUserToAddRows = false;
        dgvKetQua.AllowUserToDeleteRows = false;
        dgvKetQua.RowHeadersVisible = false;
        dgvKetQua.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        var diemStyle = new DataGridViewCellStyle
        {
            Format = "0.##",
            FormatProvider = CultureInfo.InvariantCulture,
            Alignment = DataGridViewContentAlignment.MiddleRight
        };

        dgvKetQua.Columns.Clear();
        dgvKetQua.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "colMaSV", DataPropertyName = "MaSV", HeaderText = "Mã SV", ReadOnly = true, FillWeight = 60
        });
        dgvKetQua.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "colHoTen", DataPropertyName = "HoTen", HeaderText = "Họ tên", ReadOnly = true, FillWeight = 140
        });
        dgvKetQua.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = DiemColumnName, DataPropertyName = "Diem", HeaderText = "Điểm", FillWeight = 50,
            DefaultCellStyle = diemStyle
        });
        dgvKetQua.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "colGhiChu", DataPropertyName = "GhiChu", HeaderText = "Ghi chú", FillWeight = 120
        });
    }

    private void LoadComboBoxes()
    {
        try
        {
            cboLop.DisplayMember = "TenLop";
            cboLop.ValueMember = "MaLop";
            cboLop.DataSource = dal.GetLopList();

            cboMonHoc.DisplayMember = "TenMon";
            cboMonHoc.ValueMember = "MaMon";
            cboMonHoc.DataSource = dal.GetMonHocList();

            UpdateStatus("Đã tải danh sách lớp và môn học. Hãy chọn lớp, môn học rồi bấm Tải danh sách.");
        }
        catch (SqlException ex)
        {
            ShowDbError("tải danh sách lớp và môn học", ex);
        }
    }

    private void UpdateStatus(string message)
    {
        lblStatus.Text = message;
    }

    private void ShowDbError(string action, SqlException ex)
    {
        UpdateStatus("Lỗi SQL Server");
        MessageBox.Show(
            $"Lỗi SQL Server khi {action}:\n{ex.Message}\n\nHãy kiểm tra SQL Server đang chạy, đã chạy script QLSinhVienLab12.sql và connection string trong DAL/Database.cs.",
            "Lỗi cơ sở dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    private bool HasUnsavedChanges()
    {
        if (dtKetQua == null) return false;

        dgvKetQua.EndEdit();
        bsKetQua.EndEdit();
        return dtKetQua.GetChanges() != null;
    }

    private void LoadKetQua(string maLop, string maMon)
    {
        try
        {
            dtKetQua = dal.GetByLopMon(maLop, maMon);
            bsKetQua.Filter = null;
            bsKetQua.DataSource = dtKetQua;
            txtLoc.Clear();
            loadedMaLop = maLop;
            loadedMaMon = maMon;
            UpdateStatistics();
            UpdateStatus($"Đã tải {dtKetQua.Rows.Count} sinh viên của lớp {cboLop.Text}, môn {cboMonHoc.Text}.");
        }
        catch (SqlException ex)
        {
            ShowDbError("tải danh sách sinh viên", ex);
        }
    }

    private void UpdateStatistics()
    {
        if (dtKetQua == null)
        {
            lblThongKe.Text = string.Empty;
            return;
        }

        int total = dtKetQua.Rows.Count;
        int entered = 0;
        decimal sum = 0;

        foreach (DataRow row in dtKetQua.Rows)
        {
            if (row["Diem"] != DBNull.Value)
            {
                entered++;
                sum += Convert.ToDecimal(row["Diem"]);
            }
        }

        string average = entered == 0 ? "chưa có" : (sum / entered).ToString("0.00", CultureInfo.InvariantCulture);
        lblThongKe.Text = $"Sĩ số: {total}  |  Đã nhập điểm: {entered}  |  Điểm trung bình: {average}";
    }

    private static bool TryParseDiem(string text, out decimal diem, out string error)
    {
        diem = 0;
        error = string.Empty;

        if (text.Contains(','))
        {
            error = "Dùng dấu chấm (.) làm dấu thập phân, ví dụ 8.5";
            return false;
        }

        NumberStyles styles = NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign;
        if (!decimal.TryParse(text, styles, CultureInfo.InvariantCulture, out diem))
        {
            error = "Điểm phải là một số";
            return false;
        }

        if (diem < 0 || diem > 10)
        {
            error = "Điểm phải nằm trong khoảng 0 đến 10";
            return false;
        }

        if (decimal.Round(diem, 2) != diem)
        {
            error = "Điểm chỉ được tối đa 2 chữ số thập phân";
            return false;
        }

        return true;
    }

    private bool CollectItems(out List<KetQuaItem> items)
    {
        items = new List<KetQuaItem>();
        var errors = new List<string>();

        foreach (DataRow row in dtKetQua!.Rows)
        {
            string maSV = Convert.ToString(row["MaSV"]) ?? string.Empty;

            if (row["Diem"] == DBNull.Value)
            {
                errors.Add($"{maSV}: điểm không được để trống");
                continue;
            }

            decimal diem = Convert.ToDecimal(row["Diem"]);
            if (diem < 0 || diem > 10)
            {
                errors.Add($"{maSV}: điểm {diem} nằm ngoài khoảng 0 đến 10");
                continue;
            }

            string? ghiChu = row["GhiChu"] == DBNull.Value ? null : Convert.ToString(row["GhiChu"])?.Trim();
            if (ghiChu != null && ghiChu.Length > 200)
            {
                errors.Add($"{maSV}: ghi chú dài quá 200 ký tự");
                continue;
            }

            items.Add(new KetQuaItem
            {
                MaSV = maSV,
                Diem = diem,
                GhiChu = string.IsNullOrEmpty(ghiChu) ? null : ghiChu
            });
        }

        if (errors.Count == 0) return true;

        var message = new StringBuilder("Không thể lưu vì dữ liệu chưa hợp lệ:\n\n");
        foreach (string error in errors.GetRange(0, Math.Min(errors.Count, 10)))
        {
            message.AppendLine("- " + error);
        }

        if (errors.Count > 10)
        {
            message.AppendLine($"... và {errors.Count - 10} lỗi khác.");
        }

        MessageBox.Show(message.ToString(), "Dữ liệu không hợp lệ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        UpdateStatus($"Có {errors.Count} dòng chưa hợp lệ, chưa lưu gì.");
        return false;
    }

    private static string BuildFilterText(string keyword)
    {
        var builder = new StringBuilder();
        foreach (char c in keyword)
        {
            if (c == '\'') builder.Append("''");
            else if (c == '*' || c == '%' || c == '[' || c == ']') builder.Append('[').Append(c).Append(']');
            else builder.Append(c);
        }

        return builder.ToString();
    }

    private void btnTaiDanhSach_Click(object? sender, EventArgs e)
    {
        if (cboLop.SelectedValue == null || cboMonHoc.SelectedValue == null)
        {
            MessageBox.Show("Vui lòng chọn lớp và môn học.", "Thiếu dữ liệu",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (HasUnsavedChanges())
        {
            DialogResult confirm = MessageBox.Show(
                "Bạn đang nhập điểm nhưng chưa lưu. Tải danh sách mới sẽ mất các thay đổi này. Tiếp tục?",
                "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirm != DialogResult.Yes) return;
        }

        LoadKetQua(cboLop.SelectedValue.ToString()!, cboMonHoc.SelectedValue.ToString()!);
    }

    private void btnLuuTatCa_Click(object? sender, EventArgs e)
    {
        if (dtKetQua == null || dtKetQua.Rows.Count == 0)
        {
            MessageBox.Show("Chưa có danh sách sinh viên để lưu. Hãy bấm Tải danh sách trước.", "Thông báo",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        if (!dgvKetQua.EndEdit())
        {
            MessageBox.Show("Ô đang nhập chưa hợp lệ, vui lòng sửa lại trước khi lưu.", "Dữ liệu không hợp lệ",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        bsKetQua.EndEdit();

        if (!CollectItems(out List<KetQuaItem> items)) return;

        try
        {
            int saved = dal.SaveAll(loadedMaMon, items);
            MessageBox.Show($"Đã lưu thành công {saved} dòng điểm.", "Lưu điểm",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadKetQua(loadedMaLop, loadedMaMon);
            UpdateStatus($"Đã lưu {saved} dòng điểm (commit).");
        }
        catch (SqlException ex)
        {
            UpdateStatus("Lưu thất bại, đã rollback toàn bộ.");
            MessageBox.Show(
                $"Có lỗi khi lưu nên toàn bộ thao tác đã bị hủy (rollback), không dòng nào được lưu.\n\nChi tiết: {ex.Message}",
                "Lưu thất bại", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void dgvKetQua_CellValidating(object? sender, DataGridViewCellValidatingEventArgs e)
    {
        if (e.RowIndex < 0 || dgvKetQua.Columns[e.ColumnIndex].Name != DiemColumnName) return;

        DataGridViewRow row = dgvKetQua.Rows[e.RowIndex];
        row.ErrorText = string.Empty;

        string text = (e.FormattedValue?.ToString() ?? string.Empty).Trim();
        if (text.Length == 0) return;

        if (!TryParseDiem(text, out _, out string error))
        {
            row.ErrorText = error;
            UpdateStatus(error);
            e.Cancel = true;
        }
    }

    private void dgvKetQua_CellEndEdit(object? sender, DataGridViewCellEventArgs e)
    {
        if (e.RowIndex >= 0)
        {
            dgvKetQua.Rows[e.RowIndex].ErrorText = string.Empty;
        }

        bsKetQua.EndEdit();
        UpdateStatistics();
    }

    private void dgvKetQua_DataError(object? sender, DataGridViewDataErrorEventArgs e)
    {
        e.ThrowException = false;
        UpdateStatus("Giá trị không hợp lệ: điểm phải là số từ 0 đến 10 (dùng dấu chấm).");
    }

    private void txtLoc_TextChanged(object? sender, EventArgs e)
    {
        if (dtKetQua == null) return;

        string keyword = BuildFilterText(txtLoc.Text.Trim());
        bsKetQua.Filter = keyword.Length == 0
            ? null
            : $"MaSV LIKE '%{keyword}%' OR HoTen LIKE '%{keyword}%'";
    }
}
