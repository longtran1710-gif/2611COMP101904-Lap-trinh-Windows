using System;
using System.Drawing;
using System.Windows.Forms;

namespace QLSinhVienLab12.Forms;

partial class FrmNhapDiemTheoLop
{
    private System.ComponentModel.IContainer components = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        pnlTop = new Panel();
        lblLop = new Label();
        lblMonHoc = new Label();
        lblLoc = new Label();
        cboLop = new ComboBox();
        cboMonHoc = new ComboBox();
        btnTaiDanhSach = new Button();
        btnLuuTatCa = new Button();
        txtLoc = new TextBox();
        lblThongKe = new Label();
        dgvKetQua = new DataGridView();
        lblStatus = new Label();
        ((System.ComponentModel.ISupportInitialize)dgvKetQua).BeginInit();
        SuspendLayout();

        pnlTop.Name = "pnlTop";
        pnlTop.Dock = DockStyle.Top;
        pnlTop.Height = 100;
        pnlTop.Controls.AddRange(new Control[]
        {
            lblLop, cboLop, lblMonHoc, cboMonHoc, btnTaiDanhSach, btnLuuTatCa, lblLoc, txtLoc, lblThongKe
        });

        lblLop.Name = "lblLop"; lblLop.Text = "Lớp:"; lblLop.AutoSize = true; lblLop.Location = new Point(15, 22);
        cboLop.Name = "cboLop"; cboLop.DropDownStyle = ComboBoxStyle.DropDownList;
        cboLop.Location = new Point(55, 19); cboLop.Size = new Size(200, 23);

        lblMonHoc.Name = "lblMonHoc"; lblMonHoc.Text = "Môn học:"; lblMonHoc.AutoSize = true; lblMonHoc.Location = new Point(275, 22);
        cboMonHoc.Name = "cboMonHoc"; cboMonHoc.DropDownStyle = ComboBoxStyle.DropDownList;
        cboMonHoc.Location = new Point(340, 19); cboMonHoc.Size = new Size(230, 23);

        btnTaiDanhSach.Name = "btnTaiDanhSach"; btnTaiDanhSach.Text = "Tải danh sách";
        btnTaiDanhSach.Location = new Point(590, 15); btnTaiDanhSach.Size = new Size(110, 32);
        btnTaiDanhSach.Click += btnTaiDanhSach_Click;

        btnLuuTatCa.Name = "btnLuuTatCa"; btnLuuTatCa.Text = "Lưu tất cả";
        btnLuuTatCa.Location = new Point(710, 15); btnLuuTatCa.Size = new Size(110, 32);
        btnLuuTatCa.Click += btnLuuTatCa_Click;

        lblLoc.Name = "lblLoc"; lblLoc.Text = "Lọc:"; lblLoc.AutoSize = true; lblLoc.Location = new Point(15, 66);
        txtLoc.Name = "txtLoc"; txtLoc.Location = new Point(55, 63); txtLoc.Size = new Size(200, 23);
        txtLoc.TextChanged += txtLoc_TextChanged;

        lblThongKe.Name = "lblThongKe"; lblThongKe.AutoSize = false;
        lblThongKe.Location = new Point(275, 59); lblThongKe.Size = new Size(545, 30);
        lblThongKe.TextAlign = ContentAlignment.MiddleLeft;

        dgvKetQua.Name = "dgvKetQua";
        dgvKetQua.Dock = DockStyle.Fill;
        dgvKetQua.BackgroundColor = SystemColors.Window;
        dgvKetQua.CellValidating += dgvKetQua_CellValidating;
        dgvKetQua.CellEndEdit += dgvKetQua_CellEndEdit;
        dgvKetQua.DataError += dgvKetQua_DataError;

        lblStatus.Name = "lblStatus";
        lblStatus.Dock = DockStyle.Bottom;
        lblStatus.Height = 26;
        lblStatus.TextAlign = ContentAlignment.MiddleLeft;
        lblStatus.BorderStyle = BorderStyle.Fixed3D;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(840, 560);
        MinimumSize = new Size(800, 420);
        StartPosition = FormStartPosition.CenterScreen;
        Name = "FrmNhapDiemTheoLop";
        Text = "Nhập điểm theo lớp";
        Controls.Add(dgvKetQua);
        Controls.Add(pnlTop);
        Controls.Add(lblStatus);
        Load += FrmNhapDiemTheoLop_Load;

        ((System.ComponentModel.ISupportInitialize)dgvKetQua).EndInit();
        ResumeLayout(false);
    }

    private Panel pnlTop = null!;
    private Label lblLop = null!;
    private Label lblMonHoc = null!;
    private Label lblLoc = null!;
    private ComboBox cboLop = null!;
    private ComboBox cboMonHoc = null!;
    private Button btnTaiDanhSach = null!;
    private Button btnLuuTatCa = null!;
    private TextBox txtLoc = null!;
    private Label lblThongKe = null!;
    private DataGridView dgvKetQua = null!;
    private Label lblStatus = null!;
}
