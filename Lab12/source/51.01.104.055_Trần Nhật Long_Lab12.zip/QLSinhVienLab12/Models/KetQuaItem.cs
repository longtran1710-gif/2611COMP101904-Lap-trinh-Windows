namespace QLSinhVienLab12.Models;

public class KetQuaItem
{
    public string MaSV { get; set; } = string.Empty;
    public decimal Diem { get; set; }
    public string? GhiChu { get; set; }
}
