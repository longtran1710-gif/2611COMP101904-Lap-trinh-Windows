using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using COMP1019_Lab09_StudentCard.Models;

namespace COMP1019_Lab09_StudentCard;

public static class CardRenderer
{
    public const float Ratio = 600f / 378f;
    public const int PrintWidth = 600;

    private const float BaseWidth = 600f;
    private const string SchoolName = "TRƯỜNG ĐẠI HỌC SƯ PHẠM TP. HỒ CHÍ MINH";
    private static readonly Color Accent = Color.FromArgb(0, 84, 153);

    public static Rectangle Fit(Rectangle area)
    {
        float width = area.Width;
        float height = width / Ratio;

        if (height > area.Height)
        {
            height = area.Height;
            width = height * Ratio;
        }

        int x = area.Left + (int)((area.Width - width) / 2);
        int y = area.Top + (int)((area.Height - height) / 2);
        return new Rectangle(x, y, (int)width, (int)height);
    }

    public static void Draw(Graphics g, Rectangle card, StudentInfo info, Image? photo)
    {
        if (card.Width < 60 || card.Height < 40) return;

        float s = card.Width / BaseWidth;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

        DrawBackground(g, card, info, s);
        DrawHeader(g, card, info, s);
        DrawTitle(g, card, s);
        DrawPhoto(g, card, photo, s);
        DrawInfo(g, card, info, s);
        DrawFooter(g, card, s);
    }

    private static void DrawBackground(Graphics g, Rectangle card, StudentInfo info, float s)
    {
        using (var brush = new LinearGradientBrush(card, Color.White, info.CardColor, LinearGradientMode.Vertical))
        {
            g.FillRectangle(brush, card);
        }

        using var pen = new Pen(Accent, 4 * s);
        g.DrawRectangle(pen, card.X + 2 * s, card.Y + 2 * s, card.Width - 4 * s, card.Height - 4 * s);
    }

    private static void DrawHeader(Graphics g, Rectangle card, StudentInfo info, float s)
    {
        RectangleF band = Rel(card, s, 2, 2, 596, 70);
        using (var brush = new SolidBrush(Accent))
        {
            g.FillRectangle(brush, band);
        }

        using var titleFont = new Font("Segoe UI", 16 * s, FontStyle.Bold, GraphicsUnit.Pixel);
        using var subFont = new Font("Segoe UI", 14 * s, FontStyle.Regular, GraphicsUnit.Pixel);
        using var white = new SolidBrush(Color.White);

        DrawText(g, SchoolName, titleFont, white, Rel(card, s, 10, 8, 580, 30), StringAlignment.Center);

        string khoa = string.IsNullOrWhiteSpace(info.Khoa) ? "Khoa: ..." : "Khoa " + info.Khoa;
        DrawText(g, khoa, subFont, white, Rel(card, s, 10, 38, 580, 26), StringAlignment.Center);
    }

    private static void DrawTitle(Graphics g, Rectangle card, float s)
    {
        using var font = new Font("Segoe UI", 26 * s, FontStyle.Bold, GraphicsUnit.Pixel);
        using var brush = new SolidBrush(Accent);
        DrawText(g, "THẺ SINH VIÊN", font, brush, Rel(card, s, 0, 76, 600, 42), StringAlignment.Center);
    }

    private static void DrawPhoto(Graphics g, Rectangle card, Image? photo, float s)
    {
        RectangleF box = Rel(card, s, 30, 128, 142, 190);

        using (var white = new SolidBrush(Color.White))
        {
            g.FillRectangle(white, box);
        }

        if (photo != null)
        {
            RectangleF inner = RectangleF.Inflate(box, -2 * s, -2 * s);
            g.DrawImage(photo, FitImage(photo.Size, inner));
        }
        else
        {
            using var font = new Font("Segoe UI", 15 * s, FontStyle.Bold, GraphicsUnit.Pixel);
            using var gray = new SolidBrush(Color.Gray);
            DrawText(g, "ẢNH 3x4", font, gray, box, StringAlignment.Center);
        }

        using var pen = new Pen(Accent, 2 * s);
        g.DrawRectangle(pen, box.X, box.Y, box.Width, box.Height);
    }

    private static void DrawInfo(Graphics g, Rectangle card, StudentInfo info, float s)
    {
        string[] labels = { "Mã SV:", "Họ tên:", "Ngày sinh:", "Giới tính:", "Lớp:", "Khoa:", "Khóa học:" };
        string[] values =
        {
            info.MaSV,
            info.HoTen.ToUpperInvariant(),
            info.NgaySinh.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture),
            info.GioiTinh,
            info.Lop,
            info.Khoa,
            info.KhoaHoc
        };

        using var labelFont = new Font("Segoe UI", 16 * s, FontStyle.Bold, GraphicsUnit.Pixel);
        using var valueFont = new Font("Segoe UI", 16 * s, FontStyle.Regular, GraphicsUnit.Pixel);
        using var nameFont = new Font("Segoe UI", 16 * s, FontStyle.Bold, GraphicsUnit.Pixel);
        using var labelBrush = new SolidBrush(Accent);
        using var valueBrush = new SolidBrush(Color.Black);

        for (int i = 0; i < labels.Length; i++)
        {
            float y = 128 + i * 27;
            DrawText(g, labels[i], labelFont, labelBrush, Rel(card, s, 192, y, 105, 26), StringAlignment.Near);
            Font font = i == 1 ? nameFont : valueFont;
            DrawText(g, values[i], font, valueBrush, Rel(card, s, 300, y, 288, 26), StringAlignment.Near);
        }
    }

    private static void DrawFooter(Graphics g, Rectangle card, float s)
    {
        using var pen = new Pen(Accent, 1.5f * s);
        RectangleF line = Rel(card, s, 30, 336, 540, 0);
        g.DrawLine(pen, line.X, line.Y, line.Right, line.Y);

        using var font = new Font("Segoe UI", 12 * s, FontStyle.Italic, GraphicsUnit.Pixel);
        using var brush = new SolidBrush(Color.DimGray);
        DrawText(g, "Thẻ có giá trị trong thời gian học tập tại trường", font, brush,
            Rel(card, s, 30, 340, 540, 28), StringAlignment.Center);
    }

    private static RectangleF Rel(Rectangle card, float s, float x, float y, float w, float h)
    {
        return new RectangleF(card.X + x * s, card.Y + y * s, w * s, h * s);
    }

    private static RectangleF FitImage(Size imageSize, RectangleF box)
    {
        float ratio = Math.Min(box.Width / imageSize.Width, box.Height / imageSize.Height);
        float width = imageSize.Width * ratio;
        float height = imageSize.Height * ratio;
        return new RectangleF(box.X + (box.Width - width) / 2, box.Y + (box.Height - height) / 2, width, height);
    }

    private static void DrawText(Graphics g, string text, Font font, Brush brush, RectangleF rect, StringAlignment align)
    {
        using var format = new StringFormat
        {
            Alignment = align,
            LineAlignment = StringAlignment.Center,
            Trimming = StringTrimming.EllipsisCharacter,
            FormatFlags = StringFormatFlags.NoWrap
        };
        g.DrawString(text, font, brush, rect, format);
    }
}
