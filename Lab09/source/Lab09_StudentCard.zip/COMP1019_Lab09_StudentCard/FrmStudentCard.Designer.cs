using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace COMP1019_Lab09_StudentCard;

partial class FrmStudentCard
{
    private System.ComponentModel.IContainer components = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        pnlInput = new Panel();
        grpThongTin = new GroupBox();
        lblMaSV = new Label();
        lblHoTen = new Label();
        lblNgaySinh = new Label();
        lblGioiTinh = new Label();
        lblLop = new Label();
        lblKhoa = new Label();
        lblKhoaHoc = new Label();
        txtMaSV = new TextBox();
        txtHoTen = new TextBox();
        dtpNgaySinh = new DateTimePicker();
        cboGioiTinh = new ComboBox();
        cboLop = new ComboBox();
        cboKhoa = new ComboBox();
        cboKhoaHoc = new ComboBox();
        picAvatar = new PictureBox();
        btnChonAnh = new Button();
        btnMauNen = new Button();
        btnLamMoi = new Button();
        btnXemTruoc = new Button();
        btnIn = new Button();
        btnLuuPng = new Button();
        btnThoat = new Button();
        pnlPreview = new PreviewPanel();
        lblStatus = new Label();
        errorProvider1 = new ErrorProvider(components);
        printDocument1 = new PrintDocument();
        ((System.ComponentModel.ISupportInitialize)picAvatar).BeginInit();
        SuspendLayout();

        pnlInput.Name = "pnlInput";
        pnlInput.Dock = DockStyle.Left;
        pnlInput.Width = 450;
        pnlInput.Controls.AddRange(new Control[]
        {
            grpThongTin, btnMauNen, btnLamMoi, btnXemTruoc, btnIn, btnLuuPng, btnThoat
        });

        grpThongTin.Name = "grpThongTin";
        grpThongTin.Text = "Thông tin sinh viên";
        grpThongTin.Location = new Point(10, 10);
        grpThongTin.Size = new Size(430, 285);
        grpThongTin.Controls.AddRange(new Control[]
        {
            lblMaSV, txtMaSV, lblHoTen, txtHoTen, lblNgaySinh, dtpNgaySinh, lblGioiTinh, cboGioiTinh,
            lblLop, cboLop, lblKhoa, cboKhoa, lblKhoaHoc, cboKhoaHoc, picAvatar, btnChonAnh
        });

        lblMaSV.Name = "lblMaSV"; lblMaSV.Text = "Mã sinh viên:"; lblMaSV.AutoSize = true; lblMaSV.Location = new Point(15, 33);
        txtMaSV.Name = "txtMaSV"; txtMaSV.Location = new Point(105, 30); txtMaSV.Size = new Size(190, 23);
        txtMaSV.TextChanged += InputChanged;

        lblHoTen.Name = "lblHoTen"; lblHoTen.Text = "Họ tên:"; lblHoTen.AutoSize = true; lblHoTen.Location = new Point(15, 68);
        txtHoTen.Name = "txtHoTen"; txtHoTen.Location = new Point(105, 65); txtHoTen.Size = new Size(190, 23);
        txtHoTen.TextChanged += InputChanged;

        lblNgaySinh.Name = "lblNgaySinh"; lblNgaySinh.Text = "Ngày sinh:"; lblNgaySinh.AutoSize = true; lblNgaySinh.Location = new Point(15, 103);
        dtpNgaySinh.Name = "dtpNgaySinh"; dtpNgaySinh.Format = DateTimePickerFormat.Short;
        dtpNgaySinh.Location = new Point(105, 100); dtpNgaySinh.Size = new Size(190, 23);
        dtpNgaySinh.ValueChanged += InputChanged;

        lblGioiTinh.Name = "lblGioiTinh"; lblGioiTinh.Text = "Giới tính:"; lblGioiTinh.AutoSize = true; lblGioiTinh.Location = new Point(15, 138);
        cboGioiTinh.Name = "cboGioiTinh"; cboGioiTinh.DropDownStyle = ComboBoxStyle.DropDownList;
        cboGioiTinh.Location = new Point(105, 135); cboGioiTinh.Size = new Size(190, 23);
        cboGioiTinh.SelectedIndexChanged += InputChanged;

        lblLop.Name = "lblLop"; lblLop.Text = "Lớp:"; lblLop.AutoSize = true; lblLop.Location = new Point(15, 173);
        cboLop.Name = "cboLop"; cboLop.DropDownStyle = ComboBoxStyle.DropDownList;
        cboLop.Location = new Point(105, 170); cboLop.Size = new Size(190, 23);
        cboLop.SelectedIndexChanged += InputChanged;

        lblKhoa.Name = "lblKhoa"; lblKhoa.Text = "Khoa:"; lblKhoa.AutoSize = true; lblKhoa.Location = new Point(15, 208);
        cboKhoa.Name = "cboKhoa"; cboKhoa.DropDownStyle = ComboBoxStyle.DropDownList;
        cboKhoa.Location = new Point(105, 205); cboKhoa.Size = new Size(190, 23);
        cboKhoa.SelectedIndexChanged += InputChanged;

        lblKhoaHoc.Name = "lblKhoaHoc"; lblKhoaHoc.Text = "Khóa học:"; lblKhoaHoc.AutoSize = true; lblKhoaHoc.Location = new Point(15, 243);
        cboKhoaHoc.Name = "cboKhoaHoc"; cboKhoaHoc.DropDownStyle = ComboBoxStyle.DropDownList;
        cboKhoaHoc.Location = new Point(105, 240); cboKhoaHoc.Size = new Size(190, 23);
        cboKhoaHoc.SelectedIndexChanged += InputChanged;

        picAvatar.Name = "picAvatar";
        picAvatar.BorderStyle = BorderStyle.FixedSingle;
        picAvatar.SizeMode = PictureBoxSizeMode.Zoom;
        picAvatar.BackColor = Color.WhiteSmoke;
        picAvatar.Location = new Point(315, 30);
        picAvatar.Size = new Size(100, 133);

        btnChonAnh.Name = "btnChonAnh";
        btnChonAnh.Text = "Chọn ảnh...";
        btnChonAnh.Location = new Point(315, 170);
        btnChonAnh.Size = new Size(100, 30);
        btnChonAnh.Click += btnChonAnh_Click;

        btnMauNen.Name = "btnMauNen"; btnMauNen.Text = "Màu nền thẻ"; btnMauNen.Location = new Point(10, 310);
        btnMauNen.Size = new Size(135, 36); btnMauNen.Click += btnMauNen_Click;

        btnLamMoi.Name = "btnLamMoi"; btnLamMoi.Text = "Làm mới"; btnLamMoi.Location = new Point(155, 310);
        btnLamMoi.Size = new Size(135, 36); btnLamMoi.Click += btnLamMoi_Click;

        btnLuuPng.Name = "btnLuuPng"; btnLuuPng.Text = "Lưu thẻ PNG"; btnLuuPng.Location = new Point(300, 310);
        btnLuuPng.Size = new Size(135, 36); btnLuuPng.Click += btnLuuPng_Click;

        btnXemTruoc.Name = "btnXemTruoc"; btnXemTruoc.Text = "Xem trước in"; btnXemTruoc.Location = new Point(10, 360);
        btnXemTruoc.Size = new Size(135, 36); btnXemTruoc.Click += btnXemTruoc_Click;

        btnIn.Name = "btnIn"; btnIn.Text = "In thẻ"; btnIn.Location = new Point(155, 360);
        btnIn.Size = new Size(135, 36); btnIn.Click += btnIn_Click;

        btnThoat.Name = "btnThoat"; btnThoat.Text = "Thoát"; btnThoat.Location = new Point(300, 360);
        btnThoat.Size = new Size(135, 36); btnThoat.Click += btnThoat_Click;

        pnlPreview.Name = "pnlPreview";
        pnlPreview.Dock = DockStyle.Fill;
        pnlPreview.BorderStyle = BorderStyle.FixedSingle;
        pnlPreview.Paint += pnlPreview_Paint;

        lblStatus.Name = "lblStatus";
        lblStatus.Dock = DockStyle.Bottom;
        lblStatus.Height = 26;
        lblStatus.TextAlign = ContentAlignment.MiddleLeft;
        lblStatus.BorderStyle = BorderStyle.Fixed3D;

        errorProvider1.ContainerControl = this;
        errorProvider1.BlinkStyle = ErrorBlinkStyle.NeverBlink;

        printDocument1.DocumentName = "The sinh vien";
        printDocument1.PrintPage += printDocument1_PrintPage;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(1040, 560);
        MinimumSize = new Size(900, 470);
        StartPosition = FormStartPosition.CenterScreen;
        Name = "FrmStudentCard";
        Text = "Thiết kế và in thẻ sinh viên";
        Controls.Add(pnlPreview);
        Controls.Add(pnlInput);
        Controls.Add(lblStatus);
        Load += FrmStudentCard_Load;
        FormClosed += FrmStudentCard_FormClosed;

        ((System.ComponentModel.ISupportInitialize)picAvatar).EndInit();
        ResumeLayout(false);
    }

    private Panel pnlInput = null!;
    private GroupBox grpThongTin = null!;
    private Label lblMaSV = null!;
    private Label lblHoTen = null!;
    private Label lblNgaySinh = null!;
    private Label lblGioiTinh = null!;
    private Label lblLop = null!;
    private Label lblKhoa = null!;
    private Label lblKhoaHoc = null!;
    private TextBox txtMaSV = null!;
    private TextBox txtHoTen = null!;
    private DateTimePicker dtpNgaySinh = null!;
    private ComboBox cboGioiTinh = null!;
    private ComboBox cboLop = null!;
    private ComboBox cboKhoa = null!;
    private ComboBox cboKhoaHoc = null!;
    private PictureBox picAvatar = null!;
    private Button btnChonAnh = null!;
    private Button btnMauNen = null!;
    private Button btnLamMoi = null!;
    private Button btnXemTruoc = null!;
    private Button btnIn = null!;
    private Button btnLuuPng = null!;
    private Button btnThoat = null!;
    private PreviewPanel pnlPreview = null!;
    private Label lblStatus = null!;
    private ErrorProvider errorProvider1 = null!;
    private PrintDocument printDocument1 = null!;
}
