using System;
using System.Drawing;

namespace COMP1019_Lab09_StudentCard.Models;

public class StudentInfo
{
    public string MaSV { get; set; } = string.Empty;
    public string HoTen { get; set; } = string.Empty;
    public string Lop { get; set; } = string.Empty;
    public string Khoa { get; set; } = string.Empty;
    public string KhoaHoc { get; set; } = string.Empty;
    public DateTime NgaySinh { get; set; }
    public string GioiTinh { get; set; } = string.Empty;
    public Color CardColor { get; set; } = Color.FromArgb(232, 244, 255);
}
