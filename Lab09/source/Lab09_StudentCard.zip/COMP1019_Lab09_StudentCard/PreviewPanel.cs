using System.Drawing;
using System.Windows.Forms;

namespace COMP1019_Lab09_StudentCard;

public class PreviewPanel : Panel
{
    public PreviewPanel()
    {
        DoubleBuffered = true;
        ResizeRedraw = true;
        BackColor = Color.FromArgb(214, 219, 223);
    }
}
