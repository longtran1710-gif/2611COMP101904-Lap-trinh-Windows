using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using COMP1019_Lab09_StudentCard.Models;

namespace COMP1019_Lab09_StudentCard;

public partial class FrmStudentCard : Form
{
    private static readonly DateTime DefaultBirthDate = new DateTime(2005, 1, 1);

    private Bitmap? photo;
    private Color cardColor = Color.FromArgb(232, 244, 255);

    public FrmStudentCard()
    {
        InitializeComponent();
    }

    private void FrmStudentCard_Load(object? sender, EventArgs e)
    {
        cboLop.Items.AddRange(new object[] { "49.01.CNTT.A", "49.01.CNTT.B", "50.01.CNTT.A", "50.01.CNTT.B", "51.01.CNTT.A" });
        cboKhoa.Items.AddRange(new object[]
        {
            "Công nghệ thông tin", "Toán - Tin học", "Vật lý", "Hóa học", "Ngữ văn", "Tiếng Anh"
        });
        cboKhoaHoc.Items.AddRange(new object[] { "K49", "K50", "K51", "K52" });
        cboGioiTinh.Items.AddRange(new object[] { "Nam", "Nữ", "Khác" });
        dtpNgaySinh.MaxDate = DateTime.Today;

        ResetForm();
        UpdateStatus("Sẵn sàng");
    }

    private void FrmStudentCard_FormClosed(object? sender, FormClosedEventArgs e)
    {
        photo?.Dispose();
    }

    private StudentInfo BuildStudentInfo()
    {
        return new StudentInfo
        {
            MaSV = txtMaSV.Text.Trim(),
            HoTen = txtHoTen.Text.Trim(),
            Lop = cboLop.Text,
            Khoa = cboKhoa.Text,
            KhoaHoc = cboKhoaHoc.Text,
            NgaySinh = dtpNgaySinh.Value.Date,
            GioiTinh = cboGioiTinh.Text,
            CardColor = cardColor
        };
    }

    private void UpdateStatus(string message)
    {
        lblStatus.Text = message;
    }

    private void InputChanged(object? sender, EventArgs e)
    {
        pnlPreview.Invalidate();
    }

    private void pnlPreview_Paint(object? sender, PaintEventArgs e)
    {
        Rectangle area = Rectangle.Inflate(pnlPreview.ClientRectangle, -20, -20);
        Rectangle card = CardRenderer.Fit(area);
        CardRenderer.Draw(e.Graphics, card, BuildStudentInfo(), photo);
    }

    private void ResetForm()
    {
        errorProvider1.Clear();
        txtMaSV.Clear();
        txtHoTen.Clear();
        cboLop.SelectedIndex = -1;
        cboKhoa.SelectedIndex = -1;
        cboKhoaHoc.SelectedIndex = -1;
        cboGioiTinh.SelectedIndex = 0;
        dtpNgaySinh.Value = DefaultBirthDate;
        cardColor = Color.FromArgb(232, 244, 255);

        picAvatar.Image = null;
        photo?.Dispose();
        photo = null;

        pnlPreview.Invalidate();
        txtMaSV.Focus();
    }

    private void LoadPhoto(string path)
    {
        try
        {
            using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            using var image = Image.FromStream(stream);
            Bitmap newPhoto = new Bitmap(image);

            Bitmap? oldPhoto = photo;
            photo = newPhoto;
            picAvatar.Image = photo;
            oldPhoto?.Dispose();

            errorProvider1.SetError(picAvatar, string.Empty);
            pnlPreview.Invalidate();
            UpdateStatus("Đã chọn ảnh: " + Path.GetFileName(path));
        }
        catch (Exception ex) when (ex is ArgumentException || ex is OutOfMemoryException || ex is IOException || ex is UnauthorizedAccessException)
        {
            MessageBox.Show("Không thể mở file ảnh này. Vui lòng chọn file JPG, PNG hoặc BMP hợp lệ.\n\nChi tiết: " + ex.Message,
                "Lỗi ảnh", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private bool ValidateInput()
    {
        errorProvider1.Clear();
        var missing = new System.Collections.Generic.List<string>();
        Control? firstError = null;

        if (string.IsNullOrWhiteSpace(txtMaSV.Text))
        {
            errorProvider1.SetError(txtMaSV, "Mã sinh viên không được rỗng");
            missing.Add("Mã sinh viên");
            firstError ??= txtMaSV;
        }

        if (string.IsNullOrWhiteSpace(txtHoTen.Text))
        {
            errorProvider1.SetError(txtHoTen, "Họ tên không được rỗng");
            missing.Add("Họ tên");
            firstError ??= txtHoTen;
        }

        if (photo == null)
        {
            errorProvider1.SetError(picAvatar, "Chưa chọn ảnh đại diện");
            missing.Add("Ảnh đại diện");
            firstError ??= btnChonAnh;
        }

        if (missing.Count > 0)
        {
            MessageBox.Show("Vui lòng bổ sung: " + string.Join(", ", missing) + ".",
                "Thiếu dữ liệu bắt buộc", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            firstError?.Focus();
            return false;
        }

        return true;
    }

    private void btnChonAnh_Click(object? sender, EventArgs e)
    {
        using var dialog = new OpenFileDialog();
        dialog.Title = "Chọn ảnh đại diện";
        dialog.Filter = "Image files|*.jpg;*.jpeg;*.png;*.bmp";

        if (dialog.ShowDialog() == DialogResult.OK)
        {
            LoadPhoto(dialog.FileName);
        }
    }

    private void btnMauNen_Click(object? sender, EventArgs e)
    {
        using var dialog = new ColorDialog();
        dialog.Color = cardColor;

        if (dialog.ShowDialog() == DialogResult.OK)
        {
            cardColor = dialog.Color;
            pnlPreview.Invalidate();
            UpdateStatus("Đã đổi màu nền thẻ");
        }
    }

    private void btnLamMoi_Click(object? sender, EventArgs e)
    {
        ResetForm();
        UpdateStatus("Đã làm mới biểu mẫu");
    }

    private void btnThoat_Click(object? sender, EventArgs e)
    {
        Close();
    }

    private void btnLuuPng_Click(object? sender, EventArgs e)
    {
        if (!ValidateInput()) return;

        using var dialog = new SaveFileDialog();
        dialog.Title = "Lưu thẻ sinh viên";
        dialog.Filter = "PNG image|*.png";
        dialog.FileName = "TheSinhVien_" + txtMaSV.Text.Trim() + ".png";

        if (dialog.ShowDialog() != DialogResult.OK) return;

        try
        {
            int width = 1200;
            int height = (int)(width / CardRenderer.Ratio);
            using var bitmap = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.Clear(Color.White);
                CardRenderer.Draw(g, new Rectangle(0, 0, width, height), BuildStudentInfo(), photo);
            }

            bitmap.Save(dialog.FileName, ImageFormat.Png);
            UpdateStatus("Đã lưu thẻ: " + Path.GetFileName(dialog.FileName));
        }
        catch (Exception ex) when (ex is IOException || ex is ExternalException || ex is UnauthorizedAccessException)
        {
            MessageBox.Show("Không thể lưu file: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btnXemTruoc_Click(object? sender, EventArgs e)
    {
        if (!ValidateInput()) return;

        try
        {
            using var dialog = new PrintPreviewDialog();
            dialog.Document = printDocument1;
            dialog.StartPosition = FormStartPosition.CenterParent;
            dialog.Width = 900;
            dialog.Height = 700;
            dialog.ShowDialog(this);
        }
        catch (Exception ex) when (ex is InvalidPrinterException || ex is Win32Exception)
        {
            MessageBox.Show("Không thể mở bản xem trước: " + ex.Message, "Lỗi máy in",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btnIn_Click(object? sender, EventArgs e)
    {
        if (!ValidateInput()) return;

        try
        {
            using var dialog = new PrintDialog();
            dialog.Document = printDocument1;
            dialog.UseEXDialog = true;

            if (dialog.ShowDialog(this) == DialogResult.OK)
            {
                printDocument1.Print();
                UpdateStatus("Đã gửi thẻ tới máy in");
            }
        }
        catch (Exception ex) when (ex is InvalidPrinterException || ex is Win32Exception)
        {
            MessageBox.Show("Không thể in: " + ex.Message, "Lỗi máy in", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void printDocument1_PrintPage(object? sender, PrintPageEventArgs e)
    {
        Graphics? g = e.Graphics;
        if (g == null) return;

        int width = Math.Min(e.MarginBounds.Width, CardRenderer.PrintWidth);
        int height = (int)(width / CardRenderer.Ratio);
        int x = e.MarginBounds.Left + (e.MarginBounds.Width - width) / 2;
        var area = new Rectangle(x, e.MarginBounds.Top, width, height);

        CardRenderer.Draw(g, CardRenderer.Fit(area), BuildStudentInfo(), photo);
        e.HasMorePages = false;
    }
}
