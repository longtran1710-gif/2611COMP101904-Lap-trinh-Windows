using System;
using System.Drawing;
using System.Windows.Forms;

namespace COMP1019_Lab11_LopManager;

partial class FrmLop
{
    private System.ComponentModel.IContainer components = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        grpThongTin = new GroupBox();
        lblMaLop = new Label();
        lblTenLop = new Label();
        lblKhoa = new Label();
        lblTim = new Label();
        txtMaLop = new TextBox();
        txtTenLop = new TextBox();
        cboKhoa = new ComboBox();
        txtTimKiem = new TextBox();
        btnThem = new Button();
        btnSua = new Button();
        btnXoa = new Button();
        btnLamMoi = new Button();
        btnTimKiem = new Button();
        dgvLop = new DataGridView();
        lblStatus = new Label();
        ((System.ComponentModel.ISupportInitialize)dgvLop).BeginInit();
        SuspendLayout();

        grpThongTin.Name = "grpThongTin";
        grpThongTin.Text = "Thông tin lớp học";
        grpThongTin.Dock = DockStyle.Top;
        grpThongTin.Height = 185;
        grpThongTin.Controls.AddRange(new Control[]
        {
            lblMaLop, txtMaLop, lblTenLop, txtTenLop, lblKhoa, cboKhoa,
            btnThem, btnSua, btnXoa, btnLamMoi, lblTim, txtTimKiem, btnTimKiem
        });

        lblMaLop.Name = "lblMaLop"; lblMaLop.Text = "Mã lớp:"; lblMaLop.AutoSize = true; lblMaLop.Location = new Point(15, 33);
        txtMaLop.Name = "txtMaLop"; txtMaLop.Location = new Point(90, 30); txtMaLop.Size = new Size(230, 23);

        lblTenLop.Name = "lblTenLop"; lblTenLop.Text = "Tên lớp:"; lblTenLop.AutoSize = true; lblTenLop.Location = new Point(15, 68);
        txtTenLop.Name = "txtTenLop"; txtTenLop.Location = new Point(90, 65); txtTenLop.Size = new Size(230, 23);

        lblKhoa.Name = "lblKhoa"; lblKhoa.Text = "Khoa:"; lblKhoa.AutoSize = true; lblKhoa.Location = new Point(15, 103);
        cboKhoa.Name = "cboKhoa"; cboKhoa.DropDownStyle = ComboBoxStyle.DropDownList;
        cboKhoa.Location = new Point(90, 100); cboKhoa.Size = new Size(230, 23);

        btnThem.Name = "btnThem"; btnThem.Text = "Thêm"; btnThem.Location = new Point(350, 28);
        btnThem.Size = new Size(100, 34); btnThem.Click += btnThem_Click;

        btnSua.Name = "btnSua"; btnSua.Text = "Sửa"; btnSua.Location = new Point(460, 28);
        btnSua.Size = new Size(100, 34); btnSua.Click += btnSua_Click;

        btnXoa.Name = "btnXoa"; btnXoa.Text = "Xóa"; btnXoa.Location = new Point(350, 72);
        btnXoa.Size = new Size(100, 34); btnXoa.Click += btnXoa_Click;

        btnLamMoi.Name = "btnLamMoi"; btnLamMoi.Text = "Làm mới"; btnLamMoi.Location = new Point(460, 72);
        btnLamMoi.Size = new Size(100, 34); btnLamMoi.Click += btnLamMoi_Click;

        lblTim.Name = "lblTim"; lblTim.Text = "Tìm kiếm:"; lblTim.AutoSize = true; lblTim.Location = new Point(15, 148);
        txtTimKiem.Name = "txtTimKiem"; txtTimKiem.Location = new Point(90, 145); txtTimKiem.Size = new Size(230, 23);
        txtTimKiem.KeyDown += txtTimKiem_KeyDown;

        btnTimKiem.Name = "btnTimKiem"; btnTimKiem.Text = "Tìm kiếm"; btnTimKiem.Location = new Point(350, 142);
        btnTimKiem.Size = new Size(100, 30); btnTimKiem.Click += btnTimKiem_Click;

        dgvLop.Name = "dgvLop";
        dgvLop.Dock = DockStyle.Fill;
        dgvLop.BackgroundColor = SystemColors.Window;
        dgvLop.SelectionChanged += dgvLop_SelectionChanged;

        lblStatus.Name = "lblStatus";
        lblStatus.Dock = DockStyle.Bottom;
        lblStatus.Height = 26;
        lblStatus.TextAlign = ContentAlignment.MiddleLeft;
        lblStatus.BorderStyle = BorderStyle.Fixed3D;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(640, 520);
        MinimumSize = new Size(620, 460);
        StartPosition = FormStartPosition.CenterScreen;
        Name = "FrmLop";
        Text = "Quản lý lớp học";
        Controls.Add(dgvLop);
        Controls.Add(grpThongTin);
        Controls.Add(lblStatus);
        Load += FrmLop_Load;

        ((System.ComponentModel.ISupportInitialize)dgvLop).EndInit();
        ResumeLayout(false);
    }

    private GroupBox grpThongTin = null!;
    private Label lblMaLop = null!;
    private Label lblTenLop = null!;
    private Label lblKhoa = null!;
    private Label lblTim = null!;
    private TextBox txtMaLop = null!;
    private TextBox txtTenLop = null!;
    private ComboBox cboKhoa = null!;
    private TextBox txtTimKiem = null!;
    private Button btnThem = null!;
    private Button btnSua = null!;
    private Button btnXoa = null!;
    private Button btnLamMoi = null!;
    private Button btnTimKiem = null!;
    private DataGridView dgvLop = null!;
    private Label lblStatus = null!;
}
