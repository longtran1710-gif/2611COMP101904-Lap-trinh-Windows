namespace COMP1019_Lab11_LopManager.Models;

public class Khoa
{
    public string MaKhoa { get; set; } = string.Empty;
    public string TenKhoa { get; set; } = string.Empty;
}
