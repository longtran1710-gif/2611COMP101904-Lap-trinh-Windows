namespace COMP1019_Lab11_LopManager.Models;

public class Lop
{
    public string MaLop { get; set; } = string.Empty;
    public string TenLop { get; set; } = string.Empty;
    public string? MaKhoa { get; set; }
    public string? TenKhoa { get; set; }
    public int SoSinhVien { get; set; }
}
