namespace COMP1019_Lab11_LopManager;

public static class DbConfig
{
    public const string ConnectionString =
        "Server=localhost\\SQLEXPRESS;Database=EduManagerDB;Trusted_Connection=True;TrustServerCertificate=True;";
}
