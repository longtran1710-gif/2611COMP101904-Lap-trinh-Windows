using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using COMP1019_Lab11_LopManager.Models;

namespace COMP1019_Lab11_LopManager;

public class LopRepository
{
    private const string SelectWithKhoaSql =
        "SELECT l.MaLop, l.TenLop, l.MaKhoa, k.TenKhoa, COUNT(sv.MaSV) AS SoSinhVien " +
        "FROM LOP l " +
        "INNER JOIN KHOA k ON l.MaKhoa = k.MaKhoa " +
        "LEFT JOIN SINHVIEN sv ON l.MaLop = sv.MaLop ";

    private const string GroupWithKhoaSql =
        "GROUP BY l.MaLop, l.TenLop, l.MaKhoa, k.TenKhoa ORDER BY l.MaLop";

    private const string SelectSimpleSql =
        "SELECT l.MaLop, l.TenLop, CAST(NULL AS VARCHAR(20)) AS MaKhoa, CAST(NULL AS NVARCHAR(100)) AS TenKhoa, " +
        "COUNT(sv.MaSV) AS SoSinhVien " +
        "FROM LOP l " +
        "LEFT JOIN SINHVIEN sv ON l.MaLop = sv.MaLop ";

    private const string GroupSimpleSql =
        "GROUP BY l.MaLop, l.TenLop ORDER BY l.MaLop";

    private const string FilterSql =
        "WHERE l.MaLop LIKE @Keyword OR l.TenLop LIKE @Keyword ";

    private bool? hasKhoa;

    public bool HasKhoa()
    {
        if (hasKhoa.HasValue) return hasKhoa.Value;

        const string sql = "SELECT CASE WHEN COL_LENGTH('dbo.LOP', 'MaKhoa') IS NULL THEN 0 ELSE 1 END";
        using var connection = new SqlConnection(DbConfig.ConnectionString);
        using var command = new SqlCommand(sql, connection);
        connection.Open();
        hasKhoa = Convert.ToInt32(command.ExecuteScalar()) == 1;
        return hasKhoa.Value;
    }

    public List<Khoa> GetKhoaList()
    {
        var result = new List<Khoa>();
        if (!HasKhoa()) return result;

        const string sql = "SELECT MaKhoa, TenKhoa FROM KHOA ORDER BY TenKhoa";
        using var connection = new SqlConnection(DbConfig.ConnectionString);
        using var command = new SqlCommand(sql, connection);
        connection.Open();
        using SqlDataReader reader = command.ExecuteReader();
        while (reader.Read())
        {
            result.Add(new Khoa { MaKhoa = reader.GetString(0), TenKhoa = reader.GetString(1) });
        }

        return result;
    }

    public List<Lop> GetAll()
    {
        return Query(null);
    }

    public List<Lop> Search(string keyword)
    {
        return Query(keyword);
    }

    public bool Exists(string maLop)
    {
        const string sql = "SELECT COUNT(1) FROM LOP WHERE MaLop = @MaLop";
        using var connection = new SqlConnection(DbConfig.ConnectionString);
        using var command = new SqlCommand(sql, connection);
        command.Parameters.Add("@MaLop", SqlDbType.VarChar, 20).Value = maLop;
        connection.Open();
        return Convert.ToInt32(command.ExecuteScalar()) > 0;
    }

    public int CountSinhVien(string maLop)
    {
        const string sql = "SELECT COUNT(1) FROM SINHVIEN WHERE MaLop = @MaLop";
        using var connection = new SqlConnection(DbConfig.ConnectionString);
        using var command = new SqlCommand(sql, connection);
        command.Parameters.Add("@MaLop", SqlDbType.VarChar, 20).Value = maLop;
        connection.Open();
        return Convert.ToInt32(command.ExecuteScalar());
    }

    public void Insert(Lop lop)
    {
        string sql = HasKhoa()
            ? "INSERT INTO LOP (MaLop, TenLop, MaKhoa) VALUES (@MaLop, @TenLop, @MaKhoa)"
            : "INSERT INTO LOP (MaLop, TenLop) VALUES (@MaLop, @TenLop)";

        Execute(sql, lop);
    }

    public void Update(Lop lop)
    {
        string sql = HasKhoa()
            ? "UPDATE LOP SET TenLop = @TenLop, MaKhoa = @MaKhoa WHERE MaLop = @MaLop"
            : "UPDATE LOP SET TenLop = @TenLop WHERE MaLop = @MaLop";

        Execute(sql, lop);
    }

    public void Delete(string maLop)
    {
        const string sql = "DELETE FROM LOP WHERE MaLop = @MaLop";
        using var connection = new SqlConnection(DbConfig.ConnectionString);
        using var command = new SqlCommand(sql, connection);
        command.Parameters.Add("@MaLop", SqlDbType.VarChar, 20).Value = maLop;
        connection.Open();
        command.ExecuteNonQuery();
    }

    private void Execute(string sql, Lop lop)
    {
        using var connection = new SqlConnection(DbConfig.ConnectionString);
        using var command = new SqlCommand(sql, connection);
        command.Parameters.Add("@MaLop", SqlDbType.VarChar, 20).Value = lop.MaLop;
        command.Parameters.Add("@TenLop", SqlDbType.NVarChar, 100).Value = lop.TenLop;
        if (HasKhoa())
        {
            command.Parameters.Add("@MaKhoa", SqlDbType.VarChar, 20).Value = (object?)lop.MaKhoa ?? DBNull.Value;
        }

        connection.Open();
        command.ExecuteNonQuery();
    }

    private List<Lop> Query(string? keyword)
    {
        string select = HasKhoa() ? SelectWithKhoaSql : SelectSimpleSql;
        string group = HasKhoa() ? GroupWithKhoaSql : GroupSimpleSql;
        string sql = keyword == null ? select + group : select + FilterSql + group;

        var result = new List<Lop>();
        using var connection = new SqlConnection(DbConfig.ConnectionString);
        using var command = new SqlCommand(sql, connection);
        if (keyword != null)
        {
            command.Parameters.Add("@Keyword", SqlDbType.NVarChar, 200).Value = "%" + EscapeLike(keyword) + "%";
        }

        connection.Open();
        using SqlDataReader reader = command.ExecuteReader();
        while (reader.Read())
        {
            result.Add(new Lop
            {
                MaLop = reader.GetString(0),
                TenLop = reader.GetString(1),
                MaKhoa = reader.IsDBNull(2) ? null : reader.GetString(2),
                TenKhoa = reader.IsDBNull(3) ? null : reader.GetString(3),
                SoSinhVien = reader.GetInt32(4)
            });
        }

        return result;
    }

    private static string EscapeLike(string text)
    {
        return text.Replace("[", "[[]").Replace("%", "[%]").Replace("_", "[_]");
    }
}
