using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using COMP1019_Lab11_LopManager.Models;

namespace COMP1019_Lab11_LopManager;

public partial class FrmLop : Form
{
    private readonly LopRepository repository = new LopRepository();
    private string currentKeyword = string.Empty;
    private bool isLoading;
    private bool hasKhoa;

    public FrmLop()
    {
        InitializeComponent();
    }

    private void FrmLop_Load(object? sender, EventArgs e)
    {
        ConfigureGrid();

        try
        {
            hasKhoa = repository.HasKhoa();
        }
        catch (SqlException ex)
        {
            ShowDbError("kết nối cơ sở dữ liệu", ex);
            return;
        }

        ConfigureKhoa();
        LoadData();
        ClearInput();
    }

    private void ConfigureGrid()
    {
        dgvLop.AutoGenerateColumns = false;
        dgvLop.ReadOnly = true;
        dgvLop.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvLop.MultiSelect = false;
        dgvLop.AllowUserToAddRows = false;
        dgvLop.AllowUserToDeleteRows = false;
        dgvLop.RowHeadersVisible = false;
        dgvLop.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        dgvLop.Columns.Clear();
        dgvLop.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "colMaLop", DataPropertyName = nameof(Lop.MaLop), HeaderText = "Mã lớp", FillWeight = 60
        });
        dgvLop.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "colTenLop", DataPropertyName = nameof(Lop.TenLop), HeaderText = "Tên lớp", FillWeight = 140
        });
        dgvLop.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "colTenKhoa", DataPropertyName = nameof(Lop.TenKhoa), HeaderText = "Khoa", FillWeight = 110
        });
        dgvLop.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "colSoSinhVien", DataPropertyName = nameof(Lop.SoSinhVien), HeaderText = "Số sinh viên", FillWeight = 60
        });
    }

    private void ConfigureKhoa()
    {
        lblKhoa.Visible = hasKhoa;
        cboKhoa.Visible = hasKhoa;
        dgvLop.Columns["colTenKhoa"]!.Visible = hasKhoa;

        if (!hasKhoa) return;

        try
        {
            List<Khoa> khoaList = repository.GetKhoaList();
            cboKhoa.DataSource = khoaList;
            cboKhoa.DisplayMember = nameof(Khoa.TenKhoa);
            cboKhoa.ValueMember = nameof(Khoa.MaKhoa);
        }
        catch (SqlException ex)
        {
            ShowDbError("tải danh sách khoa", ex);
        }
    }

    private void LoadData()
    {
        try
        {
            isLoading = true;
            List<Lop> data = currentKeyword.Length == 0
                ? repository.GetAll()
                : repository.Search(currentKeyword);

            dgvLop.DataSource = data;
            dgvLop.ClearSelection();

            string message = currentKeyword.Length == 0
                ? $"Đã tải {data.Count} lớp từ SQL Server"
                : $"Tìm thấy {data.Count} lớp với từ khóa \"{currentKeyword}\"";
            UpdateStatus(message);
        }
        catch (SqlException ex)
        {
            ShowDbError("tải danh sách lớp", ex);
        }
        finally
        {
            isLoading = false;
        }
    }

    private void UpdateStatus(string message)
    {
        lblStatus.Text = message;
    }

    private void ShowDbError(string action, SqlException ex)
    {
        UpdateStatus("Lỗi SQL Server");
        MessageBox.Show(
            $"Lỗi SQL Server khi {action}:\n{ex.Message}\n\nHãy kiểm tra SQL Server đang chạy và connection string trong file DbConfig.cs.",
            "Lỗi cơ sở dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    private void ClearInput()
    {
        txtMaLop.Clear();
        txtTenLop.Clear();
        txtMaLop.ReadOnly = false;
        if (hasKhoa && cboKhoa.Items.Count > 0)
        {
            cboKhoa.SelectedIndex = 0;
        }

        dgvLop.ClearSelection();
        txtMaLop.Focus();
    }

    private Lop? GetSelectedLop()
    {
        if (dgvLop.SelectedRows.Count == 0) return null;
        return dgvLop.SelectedRows[0].DataBoundItem as Lop;
    }

    private void LoadLopToForm(Lop lop)
    {
        txtMaLop.Text = lop.MaLop;
        txtTenLop.Text = lop.TenLop;
        txtMaLop.ReadOnly = true;

        if (hasKhoa && lop.MaKhoa != null)
        {
            cboKhoa.SelectedValue = lop.MaKhoa;
        }
    }

    private bool ValidateInput()
    {
        if (string.IsNullOrWhiteSpace(txtMaLop.Text))
        {
            MessageBox.Show("Mã lớp không được để trống.", "Thiếu dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtMaLop.Focus();
            return false;
        }

        if (string.IsNullOrWhiteSpace(txtTenLop.Text))
        {
            MessageBox.Show("Tên lớp không được để trống.", "Thiếu dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtTenLop.Focus();
            return false;
        }

        if (hasKhoa && cboKhoa.SelectedValue == null)
        {
            MessageBox.Show("Vui lòng chọn khoa cho lớp.", "Thiếu dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            cboKhoa.Focus();
            return false;
        }

        return true;
    }

    private Lop BuildLopFromForm()
    {
        return new Lop
        {
            MaLop = txtMaLop.Text.Trim(),
            TenLop = txtTenLop.Text.Trim(),
            MaKhoa = hasKhoa ? cboKhoa.SelectedValue?.ToString() : null
        };
    }

    private void dgvLop_SelectionChanged(object? sender, EventArgs e)
    {
        if (isLoading) return;

        Lop? lop = GetSelectedLop();
        if (lop != null)
        {
            LoadLopToForm(lop);
        }
    }

    private void btnThem_Click(object? sender, EventArgs e)
    {
        if (!ValidateInput()) return;

        Lop lop = BuildLopFromForm();

        try
        {
            if (repository.Exists(lop.MaLop))
            {
                MessageBox.Show($"Mã lớp \"{lop.MaLop}\" đã tồn tại.", "Trùng mã lớp",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMaLop.Focus();
                return;
            }

            repository.Insert(lop);
        }
        catch (SqlException ex)
        {
            ShowDbError("thêm lớp", ex);
            return;
        }

        currentKeyword = string.Empty;
        txtTimKiem.Clear();
        LoadData();
        ClearInput();
        UpdateStatus($"Đã thêm lớp {lop.MaLop}");
    }

    private void btnSua_Click(object? sender, EventArgs e)
    {
        Lop? selected = GetSelectedLop();
        if (selected == null)
        {
            MessageBox.Show("Vui lòng chọn lớp cần sửa trong danh sách.", "Chưa chọn lớp",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        if (!ValidateInput()) return;

        Lop lop = BuildLopFromForm();
        lop.MaLop = selected.MaLop;

        try
        {
            repository.Update(lop);
        }
        catch (SqlException ex)
        {
            ShowDbError("cập nhật lớp", ex);
            return;
        }

        LoadData();
        ClearInput();
        UpdateStatus($"Đã cập nhật lớp {lop.MaLop}");
    }

    private void btnXoa_Click(object? sender, EventArgs e)
    {
        Lop? selected = GetSelectedLop();
        if (selected == null)
        {
            MessageBox.Show("Vui lòng chọn lớp cần xóa trong danh sách.", "Chưa chọn lớp",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        DialogResult confirm = MessageBox.Show(
            $"Bạn có chắc muốn xóa lớp \"{selected.TenLop}\" ({selected.MaLop})?",
            "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (confirm != DialogResult.Yes) return;

        try
        {
            int count = repository.CountSinhVien(selected.MaLop);
            if (count > 0)
            {
                MessageBox.Show($"Không thể xóa lớp \"{selected.MaLop}\" vì đang có {count} sinh viên.",
                    "Không thể xóa", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            repository.Delete(selected.MaLop);
        }
        catch (SqlException ex) when (ex.Number == 547)
        {
            MessageBox.Show("Không thể xóa lớp này vì còn dữ liệu liên quan trong cơ sở dữ liệu.",
                "Lỗi khóa ngoại", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        catch (SqlException ex)
        {
            ShowDbError("xóa lớp", ex);
            return;
        }

        LoadData();
        ClearInput();
        UpdateStatus($"Đã xóa lớp {selected.MaLop}");
    }

    private void btnTimKiem_Click(object? sender, EventArgs e)
    {
        currentKeyword = txtTimKiem.Text.Trim();
        LoadData();
    }

    private void txtTimKiem_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Enter)
        {
            e.SuppressKeyPress = true;
            btnTimKiem.PerformClick();
        }
    }

    private void btnLamMoi_Click(object? sender, EventArgs e)
    {
        currentKeyword = string.Empty;
        txtTimKiem.Clear();
        LoadData();
        ClearInput();
        UpdateStatus("Đã làm mới và tải lại dữ liệu");
    }
}
