using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace COMP1019_Lab08_SimplePaint;

public partial class FrmPaint : Form
{
    private readonly List<DrawItem> items = new List<DrawItem>();
    private DrawItem? currentItem;
    private bool isDrawing;
    private Color currentColor = Color.Black;
    private Bitmap? backgroundImage;

    public FrmPaint()
    {
        InitializeComponent();
    }

    private DrawMode CurrentMode
    {
        get
        {
            string text = cboMode.SelectedItem?.ToString() ?? nameof(DrawMode.Pen);
            return Enum.TryParse(text, out DrawMode mode) ? mode : DrawMode.Pen;
        }
    }

    private void FrmPaint_Load(object? sender, EventArgs e)
    {
        cboMode.Items.AddRange(new object[] { "Pen", "Line", "Rectangle", "Ellipse" });
        cboMode.SelectedIndex = 0;
        nudWidth.Minimum = 1;
        nudWidth.Maximum = 20;
        nudWidth.Value = 3;
        pnlColorPreview.BackColor = currentColor;
        SetStatus("Sẵn sàng");
    }

    private void FrmPaint_FormClosed(object? sender, FormClosedEventArgs e)
    {
        backgroundImage?.Dispose();
    }

    private void FrmPaint_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.Control && e.KeyCode == Keys.Z)
        {
            UndoLast();
            e.SuppressKeyPress = true;
            e.Handled = true;
        }
    }

    private void SetStatus(string message)
    {
        lblStatus.Text = message + "  |  Số nét vẽ: " + items.Count;
    }

    private void RenderScene(Graphics g)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;

        if (backgroundImage != null)
        {
            g.DrawImage(backgroundImage, pnlCanvas.ClientRectangle);
        }

        foreach (DrawItem item in items)
        {
            item.Draw(g);
        }

        currentItem?.Draw(g);
    }

    private void pnlCanvas_Paint(object? sender, PaintEventArgs e)
    {
        RenderScene(e.Graphics);
    }

    private void pnlCanvas_MouseDown(object? sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left) return;

        isDrawing = true;
        currentItem = new DrawItem
        {
            Mode = CurrentMode,
            Start = e.Location,
            End = e.Location,
            Color = currentColor,
            Width = (float)nudWidth.Value,
            Filled = chkFill.Checked
        };

        if (currentItem.Mode == DrawMode.Pen)
        {
            currentItem.Points.Add(e.Location);
        }

        pnlCanvas.Invalidate();
    }

    private void pnlCanvas_MouseMove(object? sender, MouseEventArgs e)
    {
        SetStatus($"Tọa độ: X = {e.X}, Y = {e.Y}");

        if (!isDrawing || currentItem == null) return;

        currentItem.End = e.Location;

        if (currentItem.Mode == DrawMode.Pen)
        {
            currentItem.Points.Add(e.Location);
        }

        pnlCanvas.Invalidate();
    }

    private void pnlCanvas_MouseUp(object? sender, MouseEventArgs e)
    {
        if (!isDrawing || currentItem == null) return;

        currentItem.End = e.Location;

        bool isEmptyShape = currentItem.Mode != DrawMode.Pen && currentItem.Start == currentItem.End;
        if (!isEmptyShape)
        {
            items.Add(currentItem);
        }

        currentItem = null;
        isDrawing = false;
        pnlCanvas.Invalidate();
        SetStatus($"Tọa độ: X = {e.X}, Y = {e.Y}");
    }

    private void pnlCanvas_MouseLeave(object? sender, EventArgs e)
    {
        if (!isDrawing)
        {
            SetStatus("Tọa độ: ngoài vùng vẽ");
        }
    }

    private void btnColor_Click(object? sender, EventArgs e)
    {
        using var dialog = new ColorDialog();
        dialog.Color = currentColor;

        if (dialog.ShowDialog() == DialogResult.OK)
        {
            currentColor = dialog.Color;
            pnlColorPreview.BackColor = currentColor;
        }
    }

    private void btnBackColor_Click(object? sender, EventArgs e)
    {
        using var dialog = new ColorDialog();
        dialog.Color = pnlCanvas.BackColor;

        if (dialog.ShowDialog() == DialogResult.OK)
        {
            pnlCanvas.BackColor = dialog.Color;
            pnlCanvas.Invalidate();
        }
    }

    private void btnUndo_Click(object? sender, EventArgs e)
    {
        UndoLast();
    }

    private void UndoLast()
    {
        if (items.Count == 0)
        {
            SetStatus("Không còn nét vẽ để hoàn tác");
            return;
        }

        items.RemoveAt(items.Count - 1);
        pnlCanvas.Invalidate();
        SetStatus("Đã hoàn tác nét vẽ cuối");
    }

    private void btnClear_Click(object? sender, EventArgs e)
    {
        if (items.Count == 0 && backgroundImage == null)
        {
            SetStatus("Vùng vẽ đang trống");
            return;
        }

        DialogResult result = MessageBox.Show("Xóa toàn bộ vùng vẽ?", "Xác nhận",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (result != DialogResult.Yes) return;

        items.Clear();
        backgroundImage?.Dispose();
        backgroundImage = null;
        pnlCanvas.Invalidate();
        SetStatus("Đã xóa toàn bộ vùng vẽ");
    }

    private void btnOpenImage_Click(object? sender, EventArgs e)
    {
        using var dialog = new OpenFileDialog();
        dialog.Title = "Chọn ảnh nền";
        dialog.Filter = "Image files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";

        if (dialog.ShowDialog() != DialogResult.OK) return;

        try
        {
            using var stream = new FileStream(dialog.FileName, FileMode.Open, FileAccess.Read, FileShare.Read);
            using var image = Image.FromStream(stream);
            Bitmap newBackground = new Bitmap(image);
            backgroundImage?.Dispose();
            backgroundImage = newBackground;
            pnlCanvas.Invalidate();
            SetStatus("Đã mở ảnh nền");
        }
        catch (Exception ex) when (ex is ArgumentException || ex is OutOfMemoryException || ex is IOException)
        {
            MessageBox.Show("Không thể đọc file ảnh: " + ex.Message, "Lỗi",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void btnSave_Click(object? sender, EventArgs e)
    {
        using var dialog = new SaveFileDialog();
        dialog.Title = "Lưu hình vẽ";
        dialog.Filter = "PNG image|*.png";
        dialog.FileName = "SimplePaint.png";

        if (dialog.ShowDialog() != DialogResult.OK) return;

        try
        {
            using var bitmap = new Bitmap(pnlCanvas.Width, pnlCanvas.Height);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.Clear(pnlCanvas.BackColor);
                RenderScene(g);
            }

            bitmap.Save(dialog.FileName, ImageFormat.Png);
            SetStatus("Đã lưu ảnh: " + Path.GetFileName(dialog.FileName));
        }
        catch (Exception ex) when (ex is IOException || ex is ExternalException || ex is UnauthorizedAccessException)
        {
            MessageBox.Show("Không thể lưu file: " + ex.Message, "Lỗi",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
