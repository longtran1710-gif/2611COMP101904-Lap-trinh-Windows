using System;
using System.Drawing;
using System.Windows.Forms;

namespace COMP1019_Lab08_SimplePaint;

partial class FrmPaint
{
    private System.ComponentModel.IContainer components = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        pnlTools = new Panel();
        lblMode = new Label();
        cboMode = new ComboBox();
        lblWidth = new Label();
        nudWidth = new NumericUpDown();
        btnColor = new Button();
        pnlColorPreview = new Panel();
        chkFill = new CheckBox();
        btnBackColor = new Button();
        btnOpenImage = new Button();
        btnUndo = new Button();
        btnClear = new Button();
        btnSave = new Button();
        pnlCanvas = new DrawSurface();
        lblStatus = new Label();
        ((System.ComponentModel.ISupportInitialize)nudWidth).BeginInit();
        SuspendLayout();

        pnlTools.Name = "pnlTools";
        pnlTools.Dock = DockStyle.Top;
        pnlTools.Height = 50;
        pnlTools.Controls.AddRange(new Control[]
        {
            lblMode, cboMode, lblWidth, nudWidth, btnColor, pnlColorPreview, chkFill,
            btnBackColor, btnOpenImage, btnUndo, btnClear, btnSave
        });

        lblMode.Name = "lblMode";
        lblMode.Text = "Chế độ:";
        lblMode.AutoSize = true;
        lblMode.Location = new Point(10, 17);

        cboMode.Name = "cboMode";
        cboMode.DropDownStyle = ComboBoxStyle.DropDownList;
        cboMode.Location = new Point(65, 14);
        cboMode.Size = new Size(100, 23);

        lblWidth.Name = "lblWidth";
        lblWidth.Text = "Độ dày:";
        lblWidth.AutoSize = true;
        lblWidth.Location = new Point(180, 17);

        nudWidth.Name = "nudWidth";
        nudWidth.Location = new Point(235, 14);
        nudWidth.Size = new Size(55, 23);

        btnColor.Name = "btnColor";
        btnColor.Text = "Chọn màu";
        btnColor.Location = new Point(305, 11);
        btnColor.Size = new Size(85, 28);
        btnColor.Click += btnColor_Click;

        pnlColorPreview.Name = "pnlColorPreview";
        pnlColorPreview.BorderStyle = BorderStyle.FixedSingle;
        pnlColorPreview.Location = new Point(396, 13);
        pnlColorPreview.Size = new Size(24, 24);

        chkFill.Name = "chkFill";
        chkFill.Text = "Tô màu";
        chkFill.AutoSize = true;
        chkFill.Location = new Point(432, 15);

        btnBackColor.Name = "btnBackColor";
        btnBackColor.Text = "Màu nền";
        btnBackColor.Location = new Point(505, 11);
        btnBackColor.Size = new Size(80, 28);
        btnBackColor.Click += btnBackColor_Click;

        btnOpenImage.Name = "btnOpenImage";
        btnOpenImage.Text = "Ảnh nền...";
        btnOpenImage.Location = new Point(590, 11);
        btnOpenImage.Size = new Size(85, 28);
        btnOpenImage.Click += btnOpenImage_Click;

        btnUndo.Name = "btnUndo";
        btnUndo.Text = "Undo";
        btnUndo.Location = new Point(685, 11);
        btnUndo.Size = new Size(65, 28);
        btnUndo.Click += btnUndo_Click;

        btnClear.Name = "btnClear";
        btnClear.Text = "Clear";
        btnClear.Location = new Point(755, 11);
        btnClear.Size = new Size(65, 28);
        btnClear.Click += btnClear_Click;

        btnSave.Name = "btnSave";
        btnSave.Text = "Lưu PNG";
        btnSave.Location = new Point(825, 11);
        btnSave.Size = new Size(80, 28);
        btnSave.Click += btnSave_Click;

        pnlCanvas.Name = "pnlCanvas";
        pnlCanvas.Dock = DockStyle.Fill;
        pnlCanvas.BackColor = Color.White;
        pnlCanvas.BorderStyle = BorderStyle.FixedSingle;
        pnlCanvas.Paint += pnlCanvas_Paint;
        pnlCanvas.MouseDown += pnlCanvas_MouseDown;
        pnlCanvas.MouseMove += pnlCanvas_MouseMove;
        pnlCanvas.MouseUp += pnlCanvas_MouseUp;
        pnlCanvas.MouseLeave += pnlCanvas_MouseLeave;

        lblStatus.Name = "lblStatus";
        lblStatus.Dock = DockStyle.Bottom;
        lblStatus.Height = 26;
        lblStatus.TextAlign = ContentAlignment.MiddleLeft;
        lblStatus.BorderStyle = BorderStyle.Fixed3D;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(960, 640);
        MinimumSize = new Size(940, 400);
        StartPosition = FormStartPosition.CenterScreen;
        KeyPreview = true;
        Name = "FrmPaint";
        Text = "COMP1019 - Simple Paint";
        Controls.Add(pnlCanvas);
        Controls.Add(pnlTools);
        Controls.Add(lblStatus);
        Load += FrmPaint_Load;
        FormClosed += FrmPaint_FormClosed;
        KeyDown += FrmPaint_KeyDown;

        ((System.ComponentModel.ISupportInitialize)nudWidth).EndInit();
        ResumeLayout(false);
    }

    private Panel pnlTools = null!;
    private Label lblMode = null!;
    private ComboBox cboMode = null!;
    private Label lblWidth = null!;
    private NumericUpDown nudWidth = null!;
    private Button btnColor = null!;
    private Panel pnlColorPreview = null!;
    private CheckBox chkFill = null!;
    private Button btnBackColor = null!;
    private Button btnOpenImage = null!;
    private Button btnUndo = null!;
    private Button btnClear = null!;
    private Button btnSave = null!;
    private DrawSurface pnlCanvas = null!;
    private Label lblStatus = null!;
}
