using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace COMP1019_Lab08_SimplePaint;

public class DrawItem
{
    public DrawMode Mode { get; set; }
    public Point Start { get; set; }
    public Point End { get; set; }
    public Color Color { get; set; }
    public float Width { get; set; }
    public bool Filled { get; set; }
    public List<Point> Points { get; } = new List<Point>();

    public Rectangle GetBounds()
    {
        int x = Math.Min(Start.X, End.X);
        int y = Math.Min(Start.Y, End.Y);
        int width = Math.Abs(Start.X - End.X);
        int height = Math.Abs(Start.Y - End.Y);
        return new Rectangle(x, y, width, height);
    }

    public void Draw(Graphics g)
    {
        using var pen = new Pen(Color, Width);
        pen.StartCap = LineCap.Round;
        pen.EndCap = LineCap.Round;
        pen.LineJoin = LineJoin.Round;

        switch (Mode)
        {
            case DrawMode.Pen:
                DrawFreehand(g, pen);
                break;
            case DrawMode.Line:
                g.DrawLine(pen, Start, End);
                break;
            case DrawMode.Rectangle:
                DrawShape(g, pen, false);
                break;
            case DrawMode.Ellipse:
                DrawShape(g, pen, true);
                break;
        }
    }

    private void DrawFreehand(Graphics g, Pen pen)
    {
        if (Points.Count == 1)
        {
            using var brush = new SolidBrush(Color);
            float radius = Width / 2f;
            g.FillEllipse(brush, Points[0].X - radius, Points[0].Y - radius, Width, Width);
        }
        else if (Points.Count > 1)
        {
            g.DrawLines(pen, Points.ToArray());
        }
    }

    private void DrawShape(Graphics g, Pen pen, bool isEllipse)
    {
        Rectangle bounds = GetBounds();

        if (bounds.Width == 0 || bounds.Height == 0)
        {
            g.DrawLine(pen, Start, End);
            return;
        }

        if (Filled)
        {
            using var brush = new SolidBrush(Color);
            if (isEllipse) g.FillEllipse(brush, bounds);
            else g.FillRectangle(brush, bounds);
        }

        if (isEllipse) g.DrawEllipse(pen, bounds);
        else g.DrawRectangle(pen, bounds);
    }
}
