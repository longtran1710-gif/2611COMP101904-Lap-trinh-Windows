using System;
using System.Linq;
using System.Windows.Forms;
using ShopManagerMini.Data;
using ShopManagerMini.Models;

namespace ShopManagerMini.Forms;

public partial class FrmLogin : Form
{
    public User? CurrentUser { get; private set; }

    public FrmLogin()
    {
        InitializeComponent();
    }
    private void btnDangNhap_Click(object? sender, EventArgs e)
    {
        string username = txtUsername.Text.Trim();
        string password = txtPassword.Text;
        if (username.Length == 0 || password.Length == 0)
        {
            MessageBox.Show("Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu.", "Cảnh báo",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            if (username.Length == 0) txtUsername.Focus(); else txtPassword.Focus();
            return;
        }
        User? user = DataStore.Users.FirstOrDefault(u =>
            u.Username.Equals(username, StringComparison.OrdinalIgnoreCase) && u.Password == password);
        if (user == null)
        {
            MessageBox.Show("Tên đăng nhập hoặc mật khẩu không đúng.", "Đăng nhập thất bại",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            txtPassword.Clear();
            txtPassword.Focus();
            return;
        }
        CurrentUser = user;
        DialogResult = DialogResult.OK; 
    }
}
