using System;
using System.Windows.Forms;
using ShopManagerMini.Models;

namespace ShopManagerMini.Forms;

public partial class FrmMain : Form
{
    private readonly User currentUser;
    private bool isLogout;
    public bool IsLogout
    {
        get { return isLogout; }
    }
    public FrmMain(User user)
    {
        currentUser = user;
        InitializeComponent();
    }
    private void FrmMain_Load(object? sender, EventArgs e)
    {
        lblUser.Text = "Người dùng: " + currentUser.HoTen;
        lblRole.Text = "Vai trò: " + currentUser.Role;
        UpdateClock();
        tmrClock.Start();
    }
    private void tmrClock_Tick(object? sender, EventArgs e)
    {
        UpdateClock();
    }
    private void UpdateClock()
    {
        lblTime.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
    }
    private void OpenChild<T>() where T : Form, new()
    {
        foreach (Form child in MdiChildren)
        {
            if (child is T)
            {
                if (child.WindowState == FormWindowState.Minimized)
                {
                    child.WindowState = FormWindowState.Normal;
                }
                child.Activate();
                return;
            }
        }
        var form = new T();
        form.MdiParent = this;
        form.Show();
    }
    private void mnuSanPham_Click(object? sender, EventArgs e)
    {
        OpenChild<FrmProduct>();
    }
    private void mnuKhachHang_Click(object? sender, EventArgs e)
    {
        OpenChild<FrmCustomer>();
    }
    private void mnuGioiThieu_Click(object? sender, EventArgs e)
    {
        OpenChild<FrmAbout>();
    }
    private void mnuDangXuat_Click(object? sender, EventArgs e)
    {
        DialogResult result = MessageBox.Show("Bạn có chắc muốn đăng xuất?", "Đăng xuất",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (result == DialogResult.Yes)
        {
            isLogout = true;
            Close();
        }
    }
    private void mnuThoat_Click(object? sender, EventArgs e)
    {
        Close(); 
    }
    private void FrmMain_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (isLogout || e.CloseReason != CloseReason.UserClosing) return;
        DialogResult result = MessageBox.Show("Bạn có chắc muốn thoát chương trình?", "Xác nhận thoát",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (result != DialogResult.Yes)
        {
            e.Cancel = true;
        }
    }
}
