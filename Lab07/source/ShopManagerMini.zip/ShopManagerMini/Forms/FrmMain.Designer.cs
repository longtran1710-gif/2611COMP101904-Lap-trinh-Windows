using System;
using System.Drawing;
using System.Windows.Forms;

namespace ShopManagerMini.Forms;

partial class FrmMain
{
    private System.ComponentModel.IContainer components = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }
    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        menuStrip1 = new MenuStrip();
        mnuHeThong = new ToolStripMenuItem();
        mnuDangXuat = new ToolStripMenuItem();
        mnuThoat = new ToolStripMenuItem();
        mnuDanhMuc = new ToolStripMenuItem();
        mnuSanPham = new ToolStripMenuItem();
        mnuKhachHang = new ToolStripMenuItem();
        mnuTroGiup = new ToolStripMenuItem();
        mnuGioiThieu = new ToolStripMenuItem();
        statusStrip1 = new StatusStrip();
        lblUser = new ToolStripStatusLabel();
        lblRole = new ToolStripStatusLabel();
        lblTime = new ToolStripStatusLabel();
        tmrClock = new Timer(components);
        menuStrip1.SuspendLayout();
        statusStrip1.SuspendLayout();
        SuspendLayout();

        menuStrip1.Name = "menuStrip1";
        menuStrip1.Items.AddRange(new ToolStripItem[] { mnuHeThong, mnuDanhMuc, mnuTroGiup });

        mnuHeThong.Name = "mnuHeThong";
        mnuHeThong.Text = "&Hệ thống";
        mnuHeThong.DropDownItems.AddRange(new ToolStripItem[] { mnuDangXuat, mnuThoat });

        mnuDangXuat.Name = "mnuDangXuat";
        mnuDangXuat.Text = "Đăng xuất";
        mnuDangXuat.Click += mnuDangXuat_Click;

        mnuThoat.Name = "mnuThoat";
        mnuThoat.Text = "Thoát";
        mnuThoat.ShortcutKeys = Keys.Control | Keys.Q;
        mnuThoat.Click += mnuThoat_Click;

        mnuDanhMuc.Name = "mnuDanhMuc";
        mnuDanhMuc.Text = "&Danh mục";
        mnuDanhMuc.DropDownItems.AddRange(new ToolStripItem[] { mnuSanPham, mnuKhachHang });

        mnuSanPham.Name = "mnuSanPham";
        mnuSanPham.Text = "Quản lý sản phẩm";
        mnuSanPham.ShortcutKeys = Keys.Control | Keys.P;
        mnuSanPham.Click += mnuSanPham_Click;

        mnuKhachHang.Name = "mnuKhachHang";
        mnuKhachHang.Text = "Quản lý khách hàng";
        mnuKhachHang.ShortcutKeys = Keys.Control | Keys.K;
        mnuKhachHang.Click += mnuKhachHang_Click;

        mnuTroGiup.Name = "mnuTroGiup";
        mnuTroGiup.Text = "&Trợ giúp";
        mnuTroGiup.DropDownItems.AddRange(new ToolStripItem[] { mnuGioiThieu });

        mnuGioiThieu.Name = "mnuGioiThieu";
        mnuGioiThieu.Text = "Giới thiệu";
        mnuGioiThieu.Click += mnuGioiThieu_Click;
        statusStrip1.Name = "statusStrip1";
        statusStrip1.Items.AddRange(new ToolStripItem[] { lblUser, lblRole, lblTime });

        lblUser.Name = "lblUser";
        lblUser.Text = "Người dùng:";

        lblRole.Name = "lblRole";
        lblRole.Text = "Vai trò:";
        lblRole.BorderSides = ToolStripStatusLabelBorderSides.Left;

        lblTime.Name = "lblTime";
        lblTime.Spring = true;
        lblTime.TextAlign = ContentAlignment.MiddleRight;

        tmrClock.Interval = 1000;
        tmrClock.Tick += tmrClock_Tick;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(1000, 680);
        IsMdiContainer = true;
        MainMenuStrip = menuStrip1;
        StartPosition = FormStartPosition.CenterScreen;
        Name = "FrmMain";
        Text = "ShopManagerMini - Quản lý cửa hàng mini";
        Controls.Add(statusStrip1);
        Controls.Add(menuStrip1);
        Load += FrmMain_Load;
        FormClosing += FrmMain_FormClosing;

        menuStrip1.ResumeLayout(false);
        menuStrip1.PerformLayout();
        statusStrip1.ResumeLayout(false);
        statusStrip1.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }
    private MenuStrip menuStrip1 = null!;
    private ToolStripMenuItem mnuHeThong = null!;
    private ToolStripMenuItem mnuDangXuat = null!;
    private ToolStripMenuItem mnuThoat = null!;
    private ToolStripMenuItem mnuDanhMuc = null!;
    private ToolStripMenuItem mnuSanPham = null!;
    private ToolStripMenuItem mnuKhachHang = null!;
    private ToolStripMenuItem mnuTroGiup = null!;
    private ToolStripMenuItem mnuGioiThieu = null!;
    private StatusStrip statusStrip1 = null!;
    private ToolStripStatusLabel lblUser = null!;
    private ToolStripStatusLabel lblRole = null!;
    private ToolStripStatusLabel lblTime = null!;
    private Timer tmrClock = null!;
}
