using System;
using System.Drawing;
using System.Windows.Forms;

namespace ShopManagerMini.Forms;

partial class FrmCustomer
{
    private System.ComponentModel.IContainer components = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }
    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        grpThongTin = new GroupBox();
        lblMa = new Label();
        lblTen = new Label();
        lblSdt = new Label();
        lblLoai = new Label();
        lblTim = new Label();
        txtMaKH = new TextBox();
        txtHoTen = new TextBox();
        txtSoDienThoai = new TextBox();
        cboLoaiKH = new ComboBox();
        txtTimKiem = new TextBox();
        btnTimKiem = new Button();
        btnThem = new Button();
        btnSua = new Button();
        btnXoa = new Button();
        btnLamMoi = new Button();
        dgvCustomers = new DataGridView();
        lblStatus = new Label();
        errorProvider1 = new ErrorProvider(components);
        SuspendLayout();

        grpThongTin.Name = "grpThongTin";
        grpThongTin.Text = "Thông tin khách hàng";
        grpThongTin.Dock = DockStyle.Top;
        grpThongTin.Height = 190;
        grpThongTin.Controls.AddRange(new Control[]
        {
            lblMa, txtMaKH, lblTen, txtHoTen, lblSdt, txtSoDienThoai, lblLoai, cboLoaiKH,
            lblTim, txtTimKiem, btnTimKiem, btnThem, btnSua, btnXoa, btnLamMoi
        });
        lblMa.Name = "lblMa"; lblMa.Text = "Mã KH:"; lblMa.AutoSize = true; lblMa.Location = new Point(15, 33);
        txtMaKH.Name = "txtMaKH"; txtMaKH.Location = new Point(120, 30); txtMaKH.Size = new Size(210, 23);

        lblTen.Name = "lblTen"; lblTen.Text = "Họ tên:"; lblTen.AutoSize = true; lblTen.Location = new Point(15, 68);
        txtHoTen.Name = "txtHoTen"; txtHoTen.Location = new Point(120, 65); txtHoTen.Size = new Size(210, 23);

        lblSdt.Name = "lblSdt"; lblSdt.Text = "Số điện thoại:"; lblSdt.AutoSize = true; lblSdt.Location = new Point(15, 103);
        txtSoDienThoai.Name = "txtSoDienThoai"; txtSoDienThoai.Location = new Point(120, 100); txtSoDienThoai.Size = new Size(210, 23);

        lblLoai.Name = "lblLoai"; lblLoai.Text = "Loại khách hàng:"; lblLoai.AutoSize = true; lblLoai.Location = new Point(15, 138);
        cboLoaiKH.Name = "cboLoaiKH"; cboLoaiKH.DropDownStyle = ComboBoxStyle.DropDownList;
        cboLoaiKH.Location = new Point(120, 135); cboLoaiKH.Size = new Size(210, 23);

        lblTim.Name = "lblTim"; lblTim.Text = "Tìm kiếm:"; lblTim.AutoSize = true; lblTim.Location = new Point(360, 33);
        txtTimKiem.Name = "txtTimKiem"; txtTimKiem.Location = new Point(430, 30); txtTimKiem.Size = new Size(170, 23);
        txtTimKiem.KeyDown += txtTimKiem_KeyDown;
        btnTimKiem.Name = "btnTimKiem"; btnTimKiem.Text = "Tìm kiếm"; btnTimKiem.Location = new Point(610, 28);
        btnTimKiem.Size = new Size(90, 28); btnTimKiem.Click += btnTimKiem_Click;

        btnThem.Name = "btnThem"; btnThem.Text = "Thêm"; btnThem.Location = new Point(360, 80);
        btnThem.Size = new Size(110, 34); btnThem.Click += btnThem_Click;
        btnSua.Name = "btnSua"; btnSua.Text = "Sửa"; btnSua.Location = new Point(490, 80);
        btnSua.Size = new Size(110, 34); btnSua.Click += btnSua_Click;
        btnXoa.Name = "btnXoa"; btnXoa.Text = "Xóa"; btnXoa.Location = new Point(360, 128);
        btnXoa.Size = new Size(110, 34); btnXoa.Click += btnXoa_Click;
        btnLamMoi.Name = "btnLamMoi"; btnLamMoi.Text = "Làm mới"; btnLamMoi.Location = new Point(490, 128);
        btnLamMoi.Size = new Size(110, 34); btnLamMoi.Click += btnLamMoi_Click;

        dgvCustomers.Name = "dgvCustomers";
        dgvCustomers.Dock = DockStyle.Fill;
        dgvCustomers.BackgroundColor = SystemColors.Window;
        dgvCustomers.SelectionChanged += dgvCustomers_SelectionChanged;

        lblStatus.Name = "lblStatus";
        lblStatus.Dock = DockStyle.Bottom;
        lblStatus.Height = 24;
        lblStatus.TextAlign = ContentAlignment.MiddleLeft;
        lblStatus.BorderStyle = BorderStyle.Fixed3D;

        errorProvider1.ContainerControl = this;
        errorProvider1.BlinkStyle = ErrorBlinkStyle.NeverBlink;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(740, 480);
        ShowIcon = false;
        Name = "FrmCustomer";
        Text = "Quản lý khách hàng";
        Controls.Add(dgvCustomers);
        Controls.Add(grpThongTin);
        Controls.Add(lblStatus);
        Load += FrmCustomer_Load;
        ResumeLayout(false);
    }
    private GroupBox grpThongTin = null!;
    private Label lblMa = null!;
    private Label lblTen = null!;
    private Label lblSdt = null!;
    private Label lblLoai = null!;
    private Label lblTim = null!;
    private TextBox txtMaKH = null!;
    private TextBox txtHoTen = null!;
    private TextBox txtSoDienThoai = null!;
    private ComboBox cboLoaiKH = null!;
    private TextBox txtTimKiem = null!;
    private Button btnTimKiem = null!;
    private Button btnThem = null!;
    private Button btnSua = null!;
    private Button btnXoa = null!;
    private Button btnLamMoi = null!;
    private DataGridView dgvCustomers = null!;
    private Label lblStatus = null!;
    private ErrorProvider errorProvider1 = null!;
}
