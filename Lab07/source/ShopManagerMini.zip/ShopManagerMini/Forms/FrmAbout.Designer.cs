using System;
using System.Drawing;
using System.Windows.Forms;

namespace ShopManagerMini.Forms;

partial class FrmAbout
{
    private System.ComponentModel.IContainer components = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }
    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        lblTieuDe = new Label();
        lblThongTin = new Label();
        btnDong = new Button();
        SuspendLayout();

        lblTieuDe.Name = "lblTieuDe";
        lblTieuDe.Text = "SHOP MANAGER MINI";
        lblTieuDe.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTieuDe.TextAlign = ContentAlignment.MiddleCenter;
        lblTieuDe.Location = new Point(10, 15);
        lblTieuDe.Size = new Size(430, 35);

        lblThongTin.Name = "lblThongTin";
        lblThongTin.Location = new Point(30, 65);
        lblThongTin.Size = new Size(400, 150);

        btnDong.Name = "btnDong";
        btnDong.Text = "Đóng";
        btnDong.Location = new Point(175, 225);
        btnDong.Size = new Size(100, 32);
        btnDong.Click += btnDong_Click;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(450, 275);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        ShowIcon = false;
        Name = "FrmAbout";
        Text = "Giới thiệu";
        Controls.AddRange(new Control[] { lblTieuDe, lblThongTin, btnDong });
        ResumeLayout(false);
    }
    private Label lblTieuDe = null!;
    private Label lblThongTin = null!;
    private Button btnDong = null!;
}
