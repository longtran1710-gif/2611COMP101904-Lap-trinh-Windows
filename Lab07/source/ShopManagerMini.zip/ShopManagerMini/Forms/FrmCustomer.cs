using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ShopManagerMini.Data;
using ShopManagerMini.Models;

namespace ShopManagerMini.Forms;

public partial class FrmCustomer : Form
{
    private readonly List<Customer> customers = DataStore.Customers;
    private readonly BindingSource customerSource = new BindingSource();
    private string currentKeyword = string.Empty;
    private bool isLoadingGrid;

    public FrmCustomer()
    {
        InitializeComponent();
    }
    private void FrmCustomer_Load(object? sender, EventArgs e)
    {
        cboLoaiKH.Items.AddRange(new object[] { "Thường", "Thân thiết", "VIP" });
        cboLoaiKH.SelectedIndex = 0;

        ConfigureGrid();
        dgvCustomers.DataSource = customerSource;
        RefreshGrid();
        ClearInput();
        UpdateStatus("Sẵn sàng");
    }
    private void ConfigureGrid()
    {
        dgvCustomers.AutoGenerateColumns = false;
        dgvCustomers.ReadOnly = true;
        dgvCustomers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvCustomers.MultiSelect = false;
        dgvCustomers.AllowUserToAddRows = false;
        dgvCustomers.AllowUserToDeleteRows = false;
        dgvCustomers.RowHeadersVisible = false;
        dgvCustomers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        dgvCustomers.Columns.Clear();
        dgvCustomers.Columns.Add(new DataGridViewTextBoxColumn { Name = "colMaKH", DataPropertyName = "MaKH", HeaderText = "Mã KH", FillWeight = 60 });
        dgvCustomers.Columns.Add(new DataGridViewTextBoxColumn { Name = "colHoTen", DataPropertyName = "HoTen", HeaderText = "Họ tên", FillWeight = 150 });
        dgvCustomers.Columns.Add(new DataGridViewTextBoxColumn { Name = "colSDT", DataPropertyName = "SoDienThoai", HeaderText = "Số điện thoại", FillWeight = 100 });
        dgvCustomers.Columns.Add(new DataGridViewTextBoxColumn { Name = "colLoaiKH", DataPropertyName = "LoaiKH", HeaderText = "Loại khách hàng", FillWeight = 90 });
    }
    private void RefreshGrid()
    {
        isLoadingGrid = true;
        try
        {
            IEnumerable<Customer> data = customers;
            if (currentKeyword.Length > 0)
            {
                data = customers.Where(c =>
                    c.MaKH.Contains(currentKeyword, StringComparison.OrdinalIgnoreCase) ||
                    c.HoTen.Contains(currentKeyword, StringComparison.OrdinalIgnoreCase) ||
                    c.SoDienThoai.Contains(currentKeyword, StringComparison.OrdinalIgnoreCase));
            }

            customerSource.DataSource = new BindingList<Customer>(data.ToList());
            dgvCustomers.ClearSelection();
        }
        finally
        {
            isLoadingGrid = false;
        }
    }
    private void SelectCustomer(Customer customer)
    {
        foreach (DataGridViewRow row in dgvCustomers.Rows)
        {
            if (ReferenceEquals(row.DataBoundItem, customer))
            {
                dgvCustomers.ClearSelection();
                row.Selected = true;
                dgvCustomers.CurrentCell = row.Cells[0];
                break;
            }
        }
    }
    private Customer? GetSelectedCustomer()
    {
        if (dgvCustomers.SelectedRows.Count == 0 ||
            dgvCustomers.SelectedRows[0].DataBoundItem is not Customer customer)
        {
            MessageBox.Show("Vui lòng chọn một khách hàng trong danh sách.", "Thông báo",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return null;
        }

        return customer;
    }
    private void dgvCustomers_SelectionChanged(object? sender, EventArgs e)
    {
        if (isLoadingGrid || dgvCustomers.SelectedRows.Count == 0) return;

        if (dgvCustomers.SelectedRows[0].DataBoundItem is Customer customer)
        {
            LoadCustomerToForm(customer);
        }
    }
    private void LoadCustomerToForm(Customer c)
    {
        errorProvider1.Clear();
        txtMaKH.Text = c.MaKH;
        txtHoTen.Text = c.HoTen;
        txtSoDienThoai.Text = c.SoDienThoai;
        cboLoaiKH.SelectedIndex = Math.Max(0, cboLoaiKH.Items.IndexOf(c.LoaiKH));
    }
    private void FillCustomerFromForm(Customer c)
    {
        c.MaKH = txtMaKH.Text.Trim();
        c.HoTen = txtHoTen.Text.Trim();
        c.SoDienThoai = txtSoDienThoai.Text.Trim();
        c.LoaiKH = cboLoaiKH.Text;
    }
    private void ClearInput()
    {
        errorProvider1.Clear();
        txtMaKH.Clear();
        txtHoTen.Clear();
        txtSoDienThoai.Clear();
        cboLoaiKH.SelectedIndex = 0;
        dgvCustomers.ClearSelection();
        txtMaKH.Focus();
    }
    private void UpdateStatus(string message)
    {
        string count = $"Tổng số khách hàng: {customers.Count}";
        if (currentKeyword.Length > 0)
        {
            count += $" (đang hiển thị {customerSource.Count})";
        }
        lblStatus.Text = message + " | " + count;
    }
    private bool ValidateInput(Customer? editing = null)
    {
        errorProvider1.Clear();
        bool isValid = true;
        Control? firstError = null;

        void SetError(Control control, string message)
        {
            errorProvider1.SetError(control, message);
            firstError ??= control;
            isValid = false;
        }

        string ma = txtMaKH.Text.Trim();
        if (ma.Length == 0)
        {
            SetError(txtMaKH, "Mã khách hàng không được rỗng");
        }
        else if (customers.Any(c => !ReferenceEquals(c, editing) &&
                                    c.MaKH.Equals(ma, StringComparison.OrdinalIgnoreCase)))
        {
            SetError(txtMaKH, "Mã khách hàng đã tồn tại");
        }

        if (string.IsNullOrWhiteSpace(txtHoTen.Text))
        {
            SetError(txtHoTen, "Họ tên không được rỗng");
        }

        string phone = txtSoDienThoai.Text.Trim();
        if (phone.Length == 0)
        {
            SetError(txtSoDienThoai, "Số điện thoại không được rỗng");
        }
        else if (!phone.All(char.IsDigit) || phone.Length < 9 || phone.Length > 11)
        {
            SetError(txtSoDienThoai, "Số điện thoại chỉ gồm 9-11 chữ số");
        }

        if (cboLoaiKH.SelectedIndex < 0)
        {
            SetError(cboLoaiKH, "Vui lòng chọn loại khách hàng");
        }

        if (!isValid)
        {
            MessageBox.Show("Dữ liệu chưa hợp lệ, vui lòng kiểm tra các ô có biểu tượng lỗi.",
                "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            firstError?.Focus();
        }

        return isValid;
    }
    private void btnThem_Click(object? sender, EventArgs e)
    {
        if (!ValidateInput()) return;

        var customer = new Customer();
        FillCustomerFromForm(customer);
        customers.Add(customer);

        currentKeyword = string.Empty;
        txtTimKiem.Clear();
        RefreshGrid();
        ClearInput();
        UpdateStatus($"Đã thêm khách hàng {customer.MaKH}");
    }
    private void btnSua_Click(object? sender, EventArgs e)
    {
        Customer? customer = GetSelectedCustomer();
        if (customer == null) return;
        if (!ValidateInput(customer)) return;

        FillCustomerFromForm(customer);
        RefreshGrid();
        SelectCustomer(customer);
        UpdateStatus($"Đã cập nhật khách hàng {customer.MaKH}");
    }
    private void btnXoa_Click(object? sender, EventArgs e)
    {
        Customer? customer = GetSelectedCustomer();
        if (customer == null) return;

        DialogResult result = MessageBox.Show(
            $"Bạn có chắc muốn xóa khách hàng \"{customer.HoTen}\" ({customer.MaKH})?",
            "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (result != DialogResult.Yes) return;

        customers.Remove(customer);
        RefreshGrid();
        ClearInput();
        UpdateStatus($"Đã xóa khách hàng {customer.MaKH}");
    }
    private void btnLamMoi_Click(object? sender, EventArgs e)
    {
        currentKeyword = string.Empty;
        txtTimKiem.Clear();
        RefreshGrid();
        ClearInput();
        UpdateStatus("Đã làm mới dữ liệu");
    }
    private void btnTimKiem_Click(object? sender, EventArgs e)
    {
        currentKeyword = txtTimKiem.Text.Trim();
        RefreshGrid();
        ClearInput();
        UpdateStatus($"Tìm thấy {customerSource.Count} khách hàng");
    }
    private void txtTimKiem_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Enter)
        {
            e.SuppressKeyPress = true;
            btnTimKiem.PerformClick();
        }
    }
}
