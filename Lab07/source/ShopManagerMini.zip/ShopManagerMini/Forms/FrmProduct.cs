using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using ShopManagerMini.Data;
using ShopManagerMini.Models;

namespace ShopManagerMini.Forms;

public partial class FrmProduct : Form
{
    private static readonly CultureInfo Vi = new CultureInfo("vi-VN");

    private readonly List<Product> products = DataStore.Products;
    private readonly BindingSource productSource = new BindingSource();
    private string currentKeyword = string.Empty;
    private bool isLoadingGrid;

    public FrmProduct()
    {
        InitializeComponent();
    }
    private void FrmProduct_Load(object? sender, EventArgs e)
    {
        cboLoaiSP.Items.AddRange(new object[] { "Đồ uống", "Thực phẩm", "Gia dụng", "Văn phòng phẩm", "Khác" });
        cboLoaiSP.SelectedIndex = 0;
        ConfigureGrid();
        dgvProducts.DataSource = productSource;
        RefreshGrid();
        ClearInput();
        UpdateStatus("Sẵn sàng");
    }
    private void ConfigureGrid()
    {
        dgvProducts.AutoGenerateColumns = false;
        dgvProducts.ReadOnly = true;
        dgvProducts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvProducts.MultiSelect = false;
        dgvProducts.AllowUserToAddRows = false;
        dgvProducts.AllowUserToDeleteRows = false;
        dgvProducts.RowHeadersVisible = false;
        dgvProducts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        var money = new DataGridViewCellStyle
        {
            Format = "N0",
            FormatProvider = Vi,
            Alignment = DataGridViewContentAlignment.MiddleRight
        };
        dgvProducts.Columns.Clear();
        dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { Name = "colMaSP", DataPropertyName = "MaSP", HeaderText = "Mã SP", FillWeight = 60 });
        dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { Name = "colTenSP", DataPropertyName = "TenSP", HeaderText = "Tên sản phẩm", FillWeight = 150 });
        dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { Name = "colLoaiSP", DataPropertyName = "LoaiSP", HeaderText = "Loại", FillWeight = 90 });
        dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { Name = "colDonGia", DataPropertyName = "DonGia", HeaderText = "Đơn giá", FillWeight = 80, DefaultCellStyle = money });
        dgvProducts.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "colSoLuong", DataPropertyName = "SoLuong", HeaderText = "Số lượng", FillWeight = 60,
            DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleRight }
        });
    }
    private void RefreshGrid()
    {
        isLoadingGrid = true;
        try
        {
            IEnumerable<Product> data = products;
            if (currentKeyword.Length > 0)
            {
                data = products.Where(p =>
                    p.MaSP.Contains(currentKeyword, StringComparison.OrdinalIgnoreCase) ||
                    p.TenSP.Contains(currentKeyword, StringComparison.OrdinalIgnoreCase));
            }

            productSource.DataSource = new BindingList<Product>(data.ToList());
            dgvProducts.ClearSelection();
        }
        finally
        {
            isLoadingGrid = false;
        }
    }
    private void SelectProduct(Product product)
    {
        foreach (DataGridViewRow row in dgvProducts.Rows)
        {
            if (ReferenceEquals(row.DataBoundItem, product))
            {
                dgvProducts.ClearSelection();
                row.Selected = true;
                dgvProducts.CurrentCell = row.Cells[0];
                break;
            }
        }
    }
    private Product? GetSelectedProduct()
    {
        if (dgvProducts.SelectedRows.Count == 0 ||
            dgvProducts.SelectedRows[0].DataBoundItem is not Product product)
        {
            MessageBox.Show("Vui lòng chọn một sản phẩm trong danh sách.", "Thông báo",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return null;
        }

        return product;
    }
    private void dgvProducts_SelectionChanged(object? sender, EventArgs e)
    {
        if (isLoadingGrid || dgvProducts.SelectedRows.Count == 0) return;

        if (dgvProducts.SelectedRows[0].DataBoundItem is Product product)
        {
            LoadProductToForm(product);
        }
    }
    private void LoadProductToForm(Product p)
    {
        errorProvider1.Clear();
        txtMaSP.Text = p.MaSP;
        txtTenSP.Text = p.TenSP;
        cboLoaiSP.SelectedIndex = Math.Max(0, cboLoaiSP.Items.IndexOf(p.LoaiSP));
        numDonGia.Value = Math.Min(Math.Max(p.DonGia, numDonGia.Minimum), numDonGia.Maximum);
        numSoLuong.Value = Math.Min(Math.Max(p.SoLuong, numSoLuong.Minimum), numSoLuong.Maximum);
    }
    private void FillProductFromForm(Product p)
    {
        p.MaSP = txtMaSP.Text.Trim();
        p.TenSP = txtTenSP.Text.Trim();
        p.LoaiSP = cboLoaiSP.Text;
        p.DonGia = numDonGia.Value;
        p.SoLuong = (int)numSoLuong.Value;
    }
    private void ClearInput()
    {
        errorProvider1.Clear();
        txtMaSP.Clear();
        txtTenSP.Clear();
        cboLoaiSP.SelectedIndex = 0;
        numDonGia.Value = 0;
        numSoLuong.Value = 0;
        dgvProducts.ClearSelection();
        txtMaSP.Focus();
    }
    private void UpdateStatus(string message)
    {
        string count = $"Tổng số sản phẩm: {products.Count}";
        if (currentKeyword.Length > 0)
        {
            count += $" (đang hiển thị {productSource.Count})";
        }
        lblStatus.Text = message + " | " + count;
    }
    private bool ValidateInput(Product? editing = null)
    {
        errorProvider1.Clear();
        bool isValid = true;
        Control? firstError = null;

        void SetError(Control control, string message)
        {
            errorProvider1.SetError(control, message);
            firstError ??= control;
            isValid = false;
        }
        string ma = txtMaSP.Text.Trim();
        if (ma.Length == 0)
        {
            SetError(txtMaSP, "Mã sản phẩm không được rỗng");
        }
        else if (products.Any(p => !ReferenceEquals(p, editing) &&
                                   p.MaSP.Equals(ma, StringComparison.OrdinalIgnoreCase)))
        {
            SetError(txtMaSP, "Mã sản phẩm đã tồn tại");
        }
        if (string.IsNullOrWhiteSpace(txtTenSP.Text))
        {
            SetError(txtTenSP, "Tên sản phẩm không được rỗng");
        }
        if (cboLoaiSP.SelectedIndex < 0)
        {
            SetError(cboLoaiSP, "Vui lòng chọn loại sản phẩm");
        }
        if (numDonGia.Value < 0)
        {
            SetError(numDonGia, "Đơn giá không được âm");
        }
        if (numSoLuong.Value < 0)
        {
            SetError(numSoLuong, "Số lượng không được âm");
        }
        if (!isValid)
        {
            MessageBox.Show("Dữ liệu chưa hợp lệ, vui lòng kiểm tra các ô có biểu tượng lỗi.",
                "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            firstError?.Focus();
        }
        return isValid;
    }

    private void btnThem_Click(object? sender, EventArgs e)
    {
        if (!ValidateInput()) return;

        var product = new Product();
        FillProductFromForm(product);
        products.Add(product);

        currentKeyword = string.Empty;
        txtTimKiem.Clear();
        RefreshGrid();
        ClearInput();
        UpdateStatus($"Đã thêm sản phẩm {product.MaSP}");
    }
    private void btnSua_Click(object? sender, EventArgs e)
    {
        Product? product = GetSelectedProduct();
        if (product == null) return;
        if (!ValidateInput(product)) return;

        FillProductFromForm(product);
        RefreshGrid();
        SelectProduct(product);
        UpdateStatus($"Đã cập nhật sản phẩm {product.MaSP}");
    }
    private void btnXoa_Click(object? sender, EventArgs e)
    {
        Product? product = GetSelectedProduct();
        if (product == null) return;

        DialogResult result = MessageBox.Show(
            $"Bạn có chắc muốn xóa sản phẩm \"{product.TenSP}\" ({product.MaSP})?",
            "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (result != DialogResult.Yes) return;
        products.Remove(product);
        RefreshGrid();
        ClearInput();
        UpdateStatus($"Đã xóa sản phẩm {product.MaSP}");
    }
    private void btnLamMoi_Click(object? sender, EventArgs e)
    {
        currentKeyword = string.Empty;
        txtTimKiem.Clear();
        RefreshGrid();
        ClearInput();
        UpdateStatus("Đã làm mới dữ liệu");
    }
    private void btnTimKiem_Click(object? sender, EventArgs e)
    {
        currentKeyword = txtTimKiem.Text.Trim();
        RefreshGrid();
        ClearInput();
        UpdateStatus($"Tìm thấy {productSource.Count} sản phẩm");
    }
    private void txtTimKiem_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Enter)
        {
            e.SuppressKeyPress = true;
            btnTimKiem.PerformClick();
        }
    }
}
