using System;
using System.Windows.Forms;

namespace ShopManagerMini.Forms;

public partial class FrmAbout : Form
{
    private const string TenSinhVien = "[Họ và tên sinh viên]";
    private const string Lop = "[Lớp]";
    public FrmAbout()
    {
        InitializeComponent();
        lblThongTin.Text =
            "Ứng dụng: ShopManagerMini - Quản lý cửa hàng mini\r\n" +
            "Phiên bản: 1.0\r\n" +
            "Môn học: COMP1019 - Lập trình trên Windows (Buổi 7)\r\n" +
            "Công nghệ: C# WinForms, MDI, dữ liệu trong bộ nhớ\r\n\r\n" +
            "Sinh viên thực hiện: " + TenSinhVien + "\r\n" +
            "Lớp: " + Lop;
    }
    private void btnDong_Click(object? sender, EventArgs e)
    {
        Close();
    }
}
