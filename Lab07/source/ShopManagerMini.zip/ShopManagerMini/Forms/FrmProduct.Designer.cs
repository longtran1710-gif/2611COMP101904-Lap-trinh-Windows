using System;
using System.Drawing;
using System.Windows.Forms;

namespace ShopManagerMini.Forms;

partial class FrmProduct
{
    private System.ComponentModel.IContainer components = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }
    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        grpThongTin = new GroupBox();
        lblMa = new Label();
        lblTen = new Label();
        lblLoai = new Label();
        lblDonGia = new Label();
        lblSoLuong = new Label();
        lblTim = new Label();
        txtMaSP = new TextBox();
        txtTenSP = new TextBox();
        cboLoaiSP = new ComboBox();
        numDonGia = new NumericUpDown();
        numSoLuong = new NumericUpDown();
        txtTimKiem = new TextBox();
        btnTimKiem = new Button();
        btnThem = new Button();
        btnSua = new Button();
        btnXoa = new Button();
        btnLamMoi = new Button();
        dgvProducts = new DataGridView();
        lblStatus = new Label();
        errorProvider1 = new ErrorProvider(components);
        SuspendLayout();

        grpThongTin.Name = "grpThongTin";
        grpThongTin.Text = "Thông tin sản phẩm";
        grpThongTin.Dock = DockStyle.Top;
        grpThongTin.Height = 215;
        grpThongTin.Controls.AddRange(new Control[]
        {
            lblMa, txtMaSP, lblTen, txtTenSP, lblLoai, cboLoaiSP, lblDonGia, numDonGia, lblSoLuong, numSoLuong,
            lblTim, txtTimKiem, btnTimKiem, btnThem, btnSua, btnXoa, btnLamMoi
        });

        lblMa.Name = "lblMa"; lblMa.Text = "Mã SP:"; lblMa.AutoSize = true; lblMa.Location = new Point(15, 33);
        txtMaSP.Name = "txtMaSP"; txtMaSP.Location = new Point(110, 30); txtMaSP.Size = new Size(220, 23);

        lblTen.Name = "lblTen"; lblTen.Text = "Tên SP:"; lblTen.AutoSize = true; lblTen.Location = new Point(15, 68);
        txtTenSP.Name = "txtTenSP"; txtTenSP.Location = new Point(110, 65); txtTenSP.Size = new Size(220, 23);

        lblLoai.Name = "lblLoai"; lblLoai.Text = "Loại SP:"; lblLoai.AutoSize = true; lblLoai.Location = new Point(15, 103);
        cboLoaiSP.Name = "cboLoaiSP"; cboLoaiSP.DropDownStyle = ComboBoxStyle.DropDownList;
        cboLoaiSP.Location = new Point(110, 100); cboLoaiSP.Size = new Size(220, 23);

        lblDonGia.Name = "lblDonGia"; lblDonGia.Text = "Đơn giá:"; lblDonGia.AutoSize = true; lblDonGia.Location = new Point(15, 138);
        numDonGia.Name = "numDonGia"; numDonGia.Location = new Point(110, 135); numDonGia.Size = new Size(220, 23);
        numDonGia.Minimum = 0; numDonGia.Maximum = 1000000000; numDonGia.Increment = 1000; numDonGia.ThousandsSeparator = true;

        lblSoLuong.Name = "lblSoLuong"; lblSoLuong.Text = "Số lượng:"; lblSoLuong.AutoSize = true; lblSoLuong.Location = new Point(15, 173);
        numSoLuong.Name = "numSoLuong"; numSoLuong.Location = new Point(110, 170); numSoLuong.Size = new Size(220, 23);
        numSoLuong.Minimum = 0; numSoLuong.Maximum = 1000000;

        lblTim.Name = "lblTim"; lblTim.Text = "Tìm kiếm:"; lblTim.AutoSize = true; lblTim.Location = new Point(360, 33);
        txtTimKiem.Name = "txtTimKiem"; txtTimKiem.Location = new Point(430, 30); txtTimKiem.Size = new Size(170, 23);
        txtTimKiem.KeyDown += txtTimKiem_KeyDown;
        btnTimKiem.Name = "btnTimKiem"; btnTimKiem.Text = "Tìm kiếm"; btnTimKiem.Location = new Point(610, 28);
        btnTimKiem.Size = new Size(90, 28); btnTimKiem.Click += btnTimKiem_Click;

        btnThem.Name = "btnThem"; btnThem.Text = "Thêm"; btnThem.Location = new Point(360, 85);
        btnThem.Size = new Size(110, 34); btnThem.Click += btnThem_Click;
        btnSua.Name = "btnSua"; btnSua.Text = "Sửa"; btnSua.Location = new Point(490, 85);
        btnSua.Size = new Size(110, 34); btnSua.Click += btnSua_Click;
        btnXoa.Name = "btnXoa"; btnXoa.Text = "Xóa"; btnXoa.Location = new Point(360, 135);
        btnXoa.Size = new Size(110, 34); btnXoa.Click += btnXoa_Click;
        btnLamMoi.Name = "btnLamMoi"; btnLamMoi.Text = "Làm mới"; btnLamMoi.Location = new Point(490, 135);
        btnLamMoi.Size = new Size(110, 34); btnLamMoi.Click += btnLamMoi_Click;

        dgvProducts.Name = "dgvProducts";
        dgvProducts.Dock = DockStyle.Fill;
        dgvProducts.BackgroundColor = SystemColors.Window;
        dgvProducts.SelectionChanged += dgvProducts_SelectionChanged;

        lblStatus.Name = "lblStatus";
        lblStatus.Dock = DockStyle.Bottom;
        lblStatus.Height = 24;
        lblStatus.TextAlign = ContentAlignment.MiddleLeft;
        lblStatus.BorderStyle = BorderStyle.Fixed3D;

        errorProvider1.ContainerControl = this;
        errorProvider1.BlinkStyle = ErrorBlinkStyle.NeverBlink;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(760, 520);
        ShowIcon = false;
        Name = "FrmProduct";
        Text = "Quản lý sản phẩm";
        Controls.Add(dgvProducts);
        Controls.Add(grpThongTin);
        Controls.Add(lblStatus);
        Load += FrmProduct_Load;
        ResumeLayout(false);
    }
    private GroupBox grpThongTin = null!;
    private Label lblMa = null!;
    private Label lblTen = null!;
    private Label lblLoai = null!;
    private Label lblDonGia = null!;
    private Label lblSoLuong = null!;
    private Label lblTim = null!;
    private TextBox txtMaSP = null!;
    private TextBox txtTenSP = null!;
    private ComboBox cboLoaiSP = null!;
    private NumericUpDown numDonGia = null!;
    private NumericUpDown numSoLuong = null!;
    private TextBox txtTimKiem = null!;
    private Button btnTimKiem = null!;
    private Button btnThem = null!;
    private Button btnSua = null!;
    private Button btnXoa = null!;
    private Button btnLamMoi = null!;
    private DataGridView dgvProducts = null!;
    private Label lblStatus = null!;
    private ErrorProvider errorProvider1 = null!;
}
