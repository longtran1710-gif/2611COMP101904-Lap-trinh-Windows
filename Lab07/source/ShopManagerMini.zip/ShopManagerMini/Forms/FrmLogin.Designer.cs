using System;
using System.Drawing;
using System.Windows.Forms;

namespace ShopManagerMini.Forms;

partial class FrmLogin
{
    private System.ComponentModel.IContainer components = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }
    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        lblTieuDe = new Label();
        lblUsername = new Label();
        lblPassword = new Label();
        lblGoiY = new Label();
        txtUsername = new TextBox();
        txtPassword = new TextBox();
        btnDangNhap = new Button();
        btnThoat = new Button();
        SuspendLayout();

        lblTieuDe.Name = "lblTieuDe";
        lblTieuDe.Text = "ĐĂNG NHẬP HỆ THỐNG";
        lblTieuDe.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
        lblTieuDe.TextAlign = ContentAlignment.MiddleCenter;
        lblTieuDe.Location = new Point(10, 15);
        lblTieuDe.Size = new Size(340, 30);

        lblUsername.Name = "lblUsername";
        lblUsername.Text = "Tên đăng nhập:";
        lblUsername.AutoSize = true;
        lblUsername.Location = new Point(25, 68);

        txtUsername.Name = "txtUsername";
        txtUsername.Location = new Point(130, 65);
        txtUsername.Size = new Size(200, 23);

        lblPassword.Name = "lblPassword";
        lblPassword.Text = "Mật khẩu:";
        lblPassword.AutoSize = true;
        lblPassword.Location = new Point(25, 103);

        txtPassword.Name = "txtPassword";
        txtPassword.Location = new Point(130, 100);
        txtPassword.Size = new Size(200, 23);
        txtPassword.UseSystemPasswordChar = true;

        btnDangNhap.Name = "btnDangNhap";
        btnDangNhap.Text = "Đăng nhập";
        btnDangNhap.Location = new Point(130, 140);
        btnDangNhap.Size = new Size(95, 32);
        btnDangNhap.Click += btnDangNhap_Click;

        btnThoat.Name = "btnThoat";
        btnThoat.Text = "Thoát";
        btnThoat.Location = new Point(235, 140);
        btnThoat.Size = new Size(95, 32);
        btnThoat.DialogResult = DialogResult.Cancel;

        lblGoiY.Name = "lblGoiY";
        lblGoiY.Text = "Tài khoản mẫu: admin / 123 hoặc user / 123";
        lblGoiY.ForeColor = SystemColors.GrayText;
        lblGoiY.AutoSize = true;
        lblGoiY.Location = new Point(25, 190);

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(360, 225);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        AcceptButton = btnDangNhap;
        CancelButton = btnThoat;
        Name = "FrmLogin";
        Text = "Đăng nhập";
        Controls.AddRange(new Control[]
        {
            lblTieuDe, lblUsername, txtUsername, lblPassword, txtPassword, btnDangNhap, btnThoat, lblGoiY
        });
        ResumeLayout(false);
        PerformLayout();
    }
    private Label lblTieuDe = null!;
    private Label lblUsername = null!;
    private Label lblPassword = null!;
    private Label lblGoiY = null!;
    private TextBox txtUsername = null!;
    private TextBox txtPassword = null!;
    private Button btnDangNhap = null!;
    private Button btnThoat = null!;
}
