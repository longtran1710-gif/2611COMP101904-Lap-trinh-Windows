using System.Collections.Generic;
using ShopManagerMini.Models;

namespace ShopManagerMini.Data;

public static class DataStore
{
    public static readonly List<User> Users = new List<User>
    {
        new User { Username = "admin", Password = "123", HoTen = "Quản trị viên", Role = "Admin" },
        new User { Username = "user", Password = "123", HoTen = "Nhân viên bán hàng", Role = "User" }
    };
    public static readonly List<Product> Products = new List<Product>
    {
        new Product { MaSP = "SP01", TenSP = "Nước suối 500ml", LoaiSP = "Đồ uống", DonGia = 6000, SoLuong = 120 },
        new Product { MaSP = "SP02", TenSP = "Mì ly hảo hảo", LoaiSP = "Thực phẩm", DonGia = 9500, SoLuong = 80 },
        new Product { MaSP = "SP03", TenSP = "Bột giặt 1kg", LoaiSP = "Gia dụng", DonGia = 45000, SoLuong = 25 }
    };
    public static readonly List<Customer> Customers = new List<Customer>
    {
        new Customer { MaKH = "KH01", HoTen = "Nguyễn Văn An", SoDienThoai = "0901234567", LoaiKH = "Thường" },
        new Customer { MaKH = "KH02", HoTen = "Trần Thị Bình", SoDienThoai = "0912345678", LoaiKH = "VIP" }
    };
}
