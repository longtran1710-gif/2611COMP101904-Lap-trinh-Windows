using System;
using System.Windows.Forms;
using ShopManagerMini.Forms;
using ShopManagerMini.Models;

namespace ShopManagerMini;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        while (true)
        {
            User? user;
            using (var login = new FrmLogin())
            {
                if (login.ShowDialog() != DialogResult.OK) return;
                user = login.CurrentUser;
            }
            if (user == null) return;
            var main = new FrmMain(user);
            Application.Run(main);
            if (!main.IsLogout) return;
        }
    }
}
